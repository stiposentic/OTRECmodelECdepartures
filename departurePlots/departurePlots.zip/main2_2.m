


clear all

figure
set(gcf,'Position',[70 50 900 650])
[ha, pos] = tight_subplot(2, 2, [.08 .06],[.1 .1],[.1 .1])
for dd = 1:20

file = ['individualVertical_' num2str(dd,'%.2i') '.mat']
load(file)



axes(ha(1))
field = uVertical;
plot(field(:,1),pVertical,'k','linewidth',2); hold on;
plot([0 0],[1000 250],'color',[.8 .8 .8],'linewidth',2)
plot(field(:,1),pVertical,'k','linewidth',2); hold on;
%plot(field(:,1)-field(:,2),pVertical,'k--','linewidth',2);
%plot(field(:,1)+field(:,2),pVertical,'k--','linewidth',2);
plot(field(:,3),pVertical,'r','linewidth',2); hold on;
%plot(field(:,3)-field(:,4),pVertical,'r--','linewidth',2);
%plot(field(:,3)+field(:,4),pVertical,'r--','linewidth',2);
set(gca, 'YDir', 'reverse' )
%text(8.5,320,'a','fontsize',14)
text(3.5,320,'a','fontsize',14)
ylim([250 1000])
ylabel('pressure (hPa)')
xlabel('u (m/s)')

axes(ha(2))
field = vVertical;
plot(field(:,1),pVertical,'k','linewidth',2); hold on;
plot(field(:,3),pVertical,'r','linewidth',2); hold on;
plot([0 0],[1000 250],'color',[.8 .8 .8],'linewidth',2)
plot(field(:,1),pVertical,'k','linewidth',2); hold on;
plot(field(:,3),pVertical,'r','linewidth',2); hold on;
%plot(field(:,1)-field(:,2),pVertical,'k--','linewidth',2);
%plot(field(:,1)+field(:,2),pVertical,'k--','linewidth',2);
%plot(field(:,3)-field(:,4),pVertical,'r--','linewidth',2);
%plot(field(:,3)+field(:,4),pVertical,'r--','linewidth',2);
ylim([250 1000])
%text(7.5,320,'b','fontsize',14)
text(3.2,320,'b','fontsize',14)
set(gca, 'YDir', 'reverse' )
legend('YDPS','NDPS','location','northwest')
xlabel('v (m/s)')

axes(ha(3))
field = qVertical;
plot([0 0],[1000 250],'color',[.8 .8 .8],'linewidth',2); hold on
plot(field(:,1),pVertical,'k','linewidth',2); hold on;
%plot(field(:,1)-field(:,2),pVertical,'k--','linewidth',2);
%plot(field(:,1)+field(:,2),pVertical,'k--','linewidth',2);
plot(field(:,3),pVertical,'r','linewidth',2); hold on;
%plot(field(:,3)-field(:,4),pVertical,'r--','linewidth',2);
%plot(field(:,3)+field(:,4),pVertical,'r--','linewidth',2);
ylim([250 1000])
%text(1.4,320,'c','fontsize',14)
text(1.2,320,'c','fontsize',14)
set(gca, 'YDir', 'reverse' )
ylabel('pressure (hPa)')
xlabel('q (g/kg)')

axes(ha(4))
field = tVertical;
plot([0 0],[1000 250],'color',[.8 .8 .8],'linewidth',2); hold on;
plot(field(:,1),pVertical,'k','linewidth',2); hold on;
%plot(field(:,1)-field(:,2),pVertical,'k--','linewidth',2);
%plot(field(:,1)+field(:,2),pVertical,'k--','linewidth',2);
plot(field(:,3),pVertical,'r','linewidth',2); hold on;
%plot(field(:,3)-field(:,4),pVertical,'r--','linewidth',2);
%plot(field(:,3)+field(:,4),pVertical,'r--','linewidth',2);
ylim([250 1000])
%text(2.1,320,'d','fontsize',14)
text(1.3,320,'d','fontsize',14)
set(gca, 'YDir', 'reverse' )
xlabel('t (K)')

end



stop
clear all
for dd = 1:20

file = ['individualVertical_' num2str(dd,'%.2i') '.mat']
load(file)

figure
set(gcf,'Position',[70 50 900 650])
[ha, pos] = tight_subplot(2, 2, [.08 .06],[.1 .1],[.1 .1])

axes(ha(1))
field = uVertical;
plot(field(:,1),pVertical,'k','linewidth',2); hold on;
plot([0 0],[1000 250],'color',[.8 .8 .8],'linewidth',2)
plot(field(:,1),pVertical,'k','linewidth',2); hold on;
plot(field(:,1)-field(:,2),pVertical,'k--','linewidth',2);
plot(field(:,1)+field(:,2),pVertical,'k--','linewidth',2);
plot(field(:,3),pVertical,'r','linewidth',2); hold on;
plot(field(:,3)-field(:,4),pVertical,'r--','linewidth',2);
plot(field(:,3)+field(:,4),pVertical,'r--','linewidth',2);
set(gca, 'YDir', 'reverse' )
%text(8.5,320,'a','fontsize',14)
text(3.5,320,'a','fontsize',14)
ylim([250 1000])
ylabel('pressure (hPa)')
xlabel('u (m/s)')

axes(ha(2))
field = vVertical;
plot(field(:,1),pVertical,'k','linewidth',2); hold on;
plot(field(:,3),pVertical,'r','linewidth',2); hold on;
plot([0 0],[1000 250],'color',[.8 .8 .8],'linewidth',2)
plot(field(:,1),pVertical,'k','linewidth',2); hold on;
plot(field(:,3),pVertical,'r','linewidth',2); hold on;
plot(field(:,1)-field(:,2),pVertical,'k--','linewidth',2);
plot(field(:,1)+field(:,2),pVertical,'k--','linewidth',2);
plot(field(:,3)-field(:,4),pVertical,'r--','linewidth',2);
plot(field(:,3)+field(:,4),pVertical,'r--','linewidth',2);
ylim([250 1000])
%text(7.5,320,'b','fontsize',14)
text(3.2,320,'b','fontsize',14)
set(gca, 'YDir', 'reverse' )
legend('YDPS','NDPS','location','northwest')
xlabel('v (m/s)')

axes(ha(3))
field = qVertical;
plot([0 0],[1000 250],'color',[.8 .8 .8],'linewidth',2); hold on
plot(field(:,1),pVertical,'k','linewidth',2); hold on;
plot(field(:,1)-field(:,2),pVertical,'k--','linewidth',2);
plot(field(:,1)+field(:,2),pVertical,'k--','linewidth',2);
plot(field(:,3),pVertical,'r','linewidth',2); hold on;
plot(field(:,3)-field(:,4),pVertical,'r--','linewidth',2);
plot(field(:,3)+field(:,4),pVertical,'r--','linewidth',2);
ylim([250 1000])
%text(1.4,320,'c','fontsize',14)
text(1.2,320,'c','fontsize',14)
set(gca, 'YDir', 'reverse' )
ylabel('pressure (hPa)')
xlabel('q (g/kg)')

axes(ha(4))
field = tVertical;
plot([0 0],[1000 250],'color',[.8 .8 .8],'linewidth',2); hold on;
plot(field(:,1),pVertical,'k','linewidth',2); hold on;
plot(field(:,1)-field(:,2),pVertical,'k--','linewidth',2);
plot(field(:,1)+field(:,2),pVertical,'k--','linewidth',2);
plot(field(:,3),pVertical,'r','linewidth',2); hold on;
plot(field(:,3)-field(:,4),pVertical,'r--','linewidth',2);
plot(field(:,3)+field(:,4),pVertical,'r--','linewidth',2);
ylim([250 1000])
%text(2.1,320,'d','fontsize',14)
text(1.3,320,'d','fontsize',14)
set(gca, 'YDir', 'reverse' )
xlabel('t (K)')

end