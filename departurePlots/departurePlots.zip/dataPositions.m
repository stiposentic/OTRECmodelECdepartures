function [pos, dataPosOut1, dataPosOut2] = dataPositions(data)

global lonBT latBT

positions = unique(data(:,6:7),'rows');
dataPos = [];
for p = 1:length(positions)
    ind = data(:,6)>positions(p,1)-0.1 & ...
        data(:,6)<positions(p,1)+0.1 & ...
        data(:,7)>positions(p,2)-0.1 & ...
        data(:,7)<positions(p,2)+0.1;
    dataPos = [dataPos; positions(p,1) positions(p,2) ...
        nanmean(data(ind,11)) ...
        nanmean(data(ind,11)+data(ind,12))];
end
pos = dataPos;

lon = dataPos(:,1);
lat = dataPos(:,2);
func = dataPos(:,3);
F = scatteredInterpolant(lon,lat,func);
[X,Y] = meshgrid(lonBT,latBT);
%F.ExtrapolationMethod = 'none';
dataPosOut1 = F(X,Y);

lon = dataPos(:,1);
lat = dataPos(:,2);
func = dataPos(:,4);
F = scatteredInterpolant(lon,lat,func);
[X,Y] = meshgrid(lonBT,latBT);
%F.ExtrapolationMethod = 'none';
dataPosOut2 = F(X,Y);
