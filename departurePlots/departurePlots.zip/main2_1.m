%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% main.m:                                                         %
% This script calculates the average horizontal departures in a   %
% range of dates. The user sets the date range after line 28.     %
% Here we also calculate vertical profiles of the departures on   %
% standard levels.                                                %
%                                                                 %
% Code written by:                                                %
%    Stipo Sentic (copyright 2021)                                %
%    Climate and Water consortium                                 %
%    New Mexico Tech                                              %
%    stipo (dot) sentic (at) nmt (dot) edu                        %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

clear all;
close all;
format shortG
global lonB latB

%[data; year mon day lon lat count Nsondes i Nlev pressure u v q T ];

dataCntl = load('cntl.txt');
dataNodp = load('nodps.txt');
dataCntl1 = dataCntl(dataCntl(:,4)>-100 & dataCntl(:,4)<-75 & dataCntl(:,3)>0 & dataCntl(:,3)<20 & dataCntl(:,7)==1,:);
dataNodp1 = dataNodp(dataNodp(:,4)>-100 & dataNodp(:,4)<-75 & dataNodp(:,3)>0 & dataNodp(:,3)<20 & dataNodp(:,7)==12,:);
% I suggest you use data values for which status = 1 in cntl and (at the same time) status = 12 in nodps

[dataU, dataV, dataT, dataQ] = getData(dataCntl1);
[dataUN, dataVN, dataTN, dataQN] = getData(dataNodp1);

pressures = [ 1000  950 925 900 850 800 700 600 500 400 300 250 ];
%pressures = 700;
lonB = -96.11111:1.11111:-75;
latB = 0:1.11111:16;

dates = unique(dataU(:,2:3),'rows');

%%
startDate0 = [8 7; 8 11; 8 12; 8 16; 8 17; 8 18; 8 22; 8 23; ...
    8 25; 9 3; 9 4; 9 9; 9 17; 9 21; 9 22; 9 24; 9 25; 9 27; 9 28;...
    9 30];

pVertical = [];
uVertical = [];
vVertical = [];
tVertical = [];
qVertical = [];

for dd = 1:20

    startDate = startDate0(dd,:);
for ii = 1:length(pressures)
    
    PRESSURE = pressures(ii);
    fprintf('Working on pressure: %4.0f\n',PRESSURE)
    
    fig = figure('visible','off')
    set(fig, 'renderer', 'painters');
    %('visible','off')
    set(gcf,'Position',[70 50 900 650])
    MAPPING = 1;
    [ha, pos] = tight_subplot(3, 4, [.006 .02],[.1 .1],[.1 .1])
    
    for FIELD = 1:4
        
        
        if FIELD == 1
            fieldName = 'u (m/s)';
            n = 11;
            nx = 18;
            data = dataU;
            dataN = dataUN;
            multiplier = 1;
            offset = 0;
        end
        
        if FIELD == 2
            fieldName = 'v (m/s)';
            n = 14;
            nx = 19;
            data = dataV;
            dataN = dataVN;
            multiplier = 1;
            offset = 0;
        end
        
        if FIELD == 3
            fieldName = 'q (g/kg)';
            n = 11;
            nx = 16;
            data = dataQ;
            dataN = dataQN;
            multiplier = 1000;
            offset = 0;
        end
        
        if FIELD == 4
            fieldName = 'T (K)';
            n = 11;
            nx = 17;
            data = dataT;
            dataN = dataTN;
            multiplier = 1;
            offset = 0;
        end
        
        %select more dates
        %data = data(data(:,2)>=startDate(1) & data(:,3)>=startDate(2)...
        %   & data(:,2)<=endDate(1) & data(:,3)>=endDate(2),:);
        %dataN = dataN(dataN(:,2)>=startDate(1) & dataN(:,3)>=startDate(2)...
        %   & dataN(:,2)<=endDate(1) & dataN(:,3)>=endDate(2),:);
        
        % for a single date selection 
        data = data(data(:,2)==startDate(1) & data(:,3)==startDate(2),:);
        dataN = dataN(dataN(:,2)==startDate(1) & dataN(:,3)==startDate(2),:);

        
%         size(dataU)
%             size(data)
%             size(dataN)
%             data(:,1:3)
%             stop
            
        number = NaN(length(lonB),length(latB),12);
        numberN = NaN(length(lonB),length(latB),12);
        
        
        dataPres = data(data(:,8)>PRESSURE-15 & data(:,8)<PRESSURE+15,:);
        dataPresN = dataN(dataN(:,8)>PRESSURE-15 & dataN(:,8)<PRESSURE+15,:);
        
        departures = NaN(length(lonB),length(latB),8000);
        field = NaN(length(lonB),length(latB),8000);
        departuresN = NaN(length(lonB),length(latB),8000);
        fieldN = NaN(length(lonB),length(latB),8000);
        
        for jj = 1:size(dataPres,1)
            lons = dataPres(jj,6);
            lats = dataPres(jj,7);
            if lons<-96 || lons>-75
                continue
            end
            if lats<0 || lats>15
                continue
            end
            if ~isnan(lons)
                [i,j] = lonlat(lons,lats);
                field(i,j,jj) = dataPres(jj,11)*multiplier+offset;
                departures(i,j,jj) = dataPres(jj,12)*multiplier;
            end
        end
        for jj = 1:size(dataPresN,1)
            lons = dataPresN(jj,6);
            lats = dataPresN(jj,7);
            if lons<-96 || lons>-75
                continue
            end
            if lats<0 || lats>15
                continue
            end
            if ~isnan(lons)
                [i,j] = lonlat(lons,lats);
                fieldN(i,j,jj) = dataPresN(jj,11)*multiplier+offset;
                departuresN(i,j,jj) = dataPresN(jj,12)*multiplier;
            end
        end
        
        %departures(1:2,:)
        %departuresN(1:2,:)
        %var4(1:2,:)
        
        dep = nanmean(departures,3);
        var4 = nanmean(field,3);
        depN = nanmean(departuresN,3);
        var4N = nanmean(fieldN,3);
        
        
        Ndep = nansum(departures*0+1,3);
        Nvar = nansum(field*0+1,3);
        NdepN = nansum(departuresN*0+1,3);
        NvarN = nansum(fieldN*0+1,3);
        
        rmsDep = sqrt((1./Ndep).*(nansum(departures.^2,3)));
        rmsVar = sqrt((1./Nvar).*(nansum(field.^2,3)));
        rmsDepN = sqrt((1./NdepN).*(nansum(departuresN.^2,3)));
        rmsVarN = sqrt((1./NvarN).*(nansum(fieldN.^2,3)));
        
        number(:,:,ii) = Ndep;
        numberN(:,:,ii) = NdepN;
        
        numm = nansum(number,3);
        nummN = nansum(numberN,3);
        
        %[nanmean(var4(:)) max(var4(:)) min(var4(:))]
        %[nanmean(dep(:)) max(dep(:)) min(dep(:))]
        
        
%         map =  [ 69.0 56.9 100.0; ...
%             56.9 67.1 100; ...
%             56.9 90.2 100.0; ...
%             61.2 83.1 71.0; ...
%             100 100 71; ...
%             99.2 78.0 49.8; ...
%             98 43.9 40]...
%             /100.0;
        
        
        load coastlines
        
        if FIELD == 4
            addon = -nanmean(var4(:)) ;
        else
            addon = 0;
        end
        
        %ax(0+FIELD) = subplot(3,4,0+FIELD);
        axes(ha(FIELD))
        c = pcolor (lonB,latB,var4'+addon); hold on; plotlines;
        plot(coastlon,coastlat,'k')
        set(c,'EdgeColor','none');
        cb = colorbar('location','northoutside');
        if FIELD == 1 & MAPPING == 1
            caxis([-12 9]) % sets colorbar limits
            set(cb,'xtick',[-12 -9 -6 -3 0 3 6 9])
            LABELadd = '';
        end
        if FIELD == 2 & MAPPING == 1
            caxis([-6 9]) % sets colorbar limits
            set(cb,'xtick',[-6 -3 0 3 6 9])
            LABELadd = '';
        end
        if FIELD == 3 & MAPPING == 1
            caxis([2 12]) % sets colorbar limits
            set(cb,'xtick',[2 4 6 8 10 12])
            LABELadd = '';
        end
        if FIELD == 4 & MAPPING == 1
            caxis([-2 2]) % sets colorbar limits
            set(cb,'xtick',[-2 -1 0 1 2])
            LABELadd = num2str(addon,'%5.2f');
        end
        axis equal
        xlim([-100 -65])
        ylim([0 20])
        title([fieldName ', OBS' LABELadd ])
        
        
        %ax(4+FIELD) = subplot(3,4,4+FIELD);
        axes(ha(4+FIELD))
        c = pcolor (lonB,latB,dep'); hold on; plotlines;
        plot(coastlon,coastlat,'k')
        set(c,'EdgeColor','none');
        cb = colorbar('location','northoutside');
        if FIELD == 0
            caxis([-7 7]) % sets colorbar limits
            set(cb,'xtick',[-7 -5 -3 -1 1 3 5 7])
        end
        
        if FIELD == 1 & MAPPING == 1
            caxis([-7 7]) % sets colorbar limits
            set(cb,'xtick',[-7 -5 -3 -1 1 3 5 7])
        end
        if FIELD == 2 & MAPPING == 1
            caxis([-11 7]) % sets colorbar limits
            set(cb,'xtick',[-11 -9 -7 -5 -3 -1 1 3 5 7])
        end
        if FIELD == 3 & MAPPING == 1
            caxis([-2.5 3.5]) % sets colorbar limits
            set(cb,'xtick',[-2.5 -1.5 -0.5 0.5 1.5 2.5 3.5])
        end
        if FIELD == 4 & MAPPING == 1
            caxis([-2 2]) % sets colorbar limits
            set(cb,'xtick',[-2 -1.5 -0.5 0.5 1.5 2])
        end
        axis equal
        xlim([-100 -65])
        ylim([0 20])
        title([fieldName  ', YDPS departures'])
        
        %ax(8+FIELD) = subplot(3,4,8+FIELD);
        axes(ha(8+FIELD))
        c = pcolor (lonB,latB,depN'); hold on; plotlines;
        plot(coastlon,coastlat,'k')
        set(c,'EdgeColor','none');
        cb = colorbar('location','northoutside');
        if FIELD == 0
            caxis([-7 7]) % sets colorbar limits
            set(cb,'xtick',[-7 -5 -3 -1 1 3 5 7])
        end
        
        if FIELD == 1 & MAPPING == 1
            %caxis([-9 5]) % sets colorbar limits
            %set(cb,'xtick',[-9 -7 -5 -3 -1 1 3 5])
            caxis([-7 7]) % sets colorbar limits
            set(cb,'xtick',[-7 -5 -3 -1 1 3 5 7])

        end
        if FIELD == 2 & MAPPING == 1
            caxis([-11 7]) % sets colorbar limits
            set(cb,'xtick',[-11 -9 -7 -5 -3 -1 1 3 5 7])
        end
        if FIELD == 3 & MAPPING == 1
            caxis([-2.5 3.5]) % sets colorbar limits
            set(cb,'xtick',[-2.5 -1.5 -0.5 0.5 1.5 2.5 3.5])

        end
        if FIELD == 4 & MAPPING == 1
            caxis([-2 2]) % sets colorbar limits
            set(cb,'xtick',[-2 -1.25 -0.5 0.5 1.25 2])
        end
        axis equal
        xlim([-100 -65])
        ylim([0 20])
        title([fieldName  ', NDPS departures'])
        
        
        if FIELD == 1
            uVertical = [uVertical; nanmean(dep(:)) nanstd(dep(:)) nanmean(depN(:)) nanstd(depN(:)) nanmean(var4(:))];
        elseif FIELD == 2
            vVertical = [vVertical; nanmean(dep(:)) nanstd(dep(:)) nanmean(depN(:)) nanstd(depN(:)) nanmean(var4(:))];
        elseif FIELD == 3
            qVertical = [qVertical; nanmean(dep(:)) nanstd(dep(:)) nanmean(depN(:)) nanstd(depN(:)) nanmean(var4(:))];
        elseif FIELD == 4
            tVertical = [tVertical; nanmean(dep(:)) nanstd(dep(:)) nanmean(depN(:)) nanstd(depN(:)) nanmean(var4(:))];
        end
    end
    
    
    if MAPPING == 1
        mappingColors
        colormap(ha(1),map1)
        colormap(ha(2),map2)
        colormap(ha(3),map3)
        colormap(ha(4),map4)
        
        colormap(ha(5),map5)
        colormap(ha(6),map6)
        colormap(ha(7),map7)
        colormap(ha(8),map8)
        
        colormap(ha(9),map9)
        colormap(ha(10),map10)
        colormap(ha(11),map11)
        colormap(ha(12),map12)
    end
    
    axes(ha(1))
    %text(-70,35,['Pressure: ' num2str(PRESSURE) ' hPa, averaging period: ' ...
    %    num2str(startDate(1),'%.2i') '-' num2str(startDate(2),'%.2i') ' to '...
    %    num2str(endDate(1),'%.2i') '-' num2str(endDate(2),'%.2i')],'fontsize',14)
    
    %print('-dpng',['departuresALL_' num2str(startDate(1),'%.2i') num2str(startDate(2),'%.2i') '_'...
    %    num2str(endDate(1),'%.2i') num2str(endDate(2),'%.2i') '_' num2str(PRESSURE,'%.4i') '.png'])
    %print('-depsc2',['departuresALL_' num2str(startDate(1),'%.2i') num2str(startDate(2),'%.2i') '_'...
    %    num2str(endDate(1),'%.2i') num2str(endDate(2),'%.2i') '_' num2str(PRESSURE,'%.4i') '.eps'])

    pVertical = [pVertical; PRESSURE];
end
close all
    
save(['individualVertical_' num2str(dd,'%.2i') '.mat'], 'pVertical',...
    'uVertical','vVertical','tVertical','qVertical')
pVertical = [];
uVertical = [];
vVertical = [];
tVertical = [];
qVertical = [];

end % dd loop 

%%
figure
set(gcf,'Position',[70 50 900 650])
[ha, pos] = tight_subplot(2, 2, [.08 .06],[.1 .1],[.1 .1])

axes(ha(1))
field = uVertical;
plot(field(:,1),pVertical,'k','linewidth',2); hold on;
plot([0 0],[1000 250],'color',[.8 .8 .8],'linewidth',2)
plot(field(:,1),pVertical,'k','linewidth',2); hold on;
plot(field(:,1)-field(:,2),pVertical,'k--','linewidth',2);
plot(field(:,1)+field(:,2),pVertical,'k--','linewidth',2);
plot(field(:,3),pVertical,'r','linewidth',2); hold on;
plot(field(:,3)-field(:,4),pVertical,'r--','linewidth',2);
plot(field(:,3)+field(:,4),pVertical,'r--','linewidth',2);
set(gca, 'YDir', 'reverse' )
%text(8.5,320,'a','fontsize',14)
text(3.5,320,'a','fontsize',14)
ylim([250 1000])
ylabel('pressure (hPa)')
xlabel('u (m/s)')

axes(ha(2))
field = vVertical;
plot(field(:,1),pVertical,'k','linewidth',2); hold on;
plot(field(:,3),pVertical,'r','linewidth',2); hold on;
plot([0 0],[1000 250],'color',[.8 .8 .8],'linewidth',2)
plot(field(:,1),pVertical,'k','linewidth',2); hold on;
plot(field(:,3),pVertical,'r','linewidth',2); hold on;
plot(field(:,1)-field(:,2),pVertical,'k--','linewidth',2);
plot(field(:,1)+field(:,2),pVertical,'k--','linewidth',2);
plot(field(:,3)-field(:,4),pVertical,'r--','linewidth',2);
plot(field(:,3)+field(:,4),pVertical,'r--','linewidth',2);
ylim([250 1000])
%text(7.5,320,'b','fontsize',14)
text(3.2,320,'b','fontsize',14)
set(gca, 'YDir', 'reverse' )
legend('YDPS','NDPS','location','northwest')
xlabel('v (m/s)')

axes(ha(3))
field = qVertical;
plot([0 0],[1000 250],'color',[.8 .8 .8],'linewidth',2); hold on
plot(field(:,1),pVertical,'k','linewidth',2); hold on;
plot(field(:,1)-field(:,2),pVertical,'k--','linewidth',2);
plot(field(:,1)+field(:,2),pVertical,'k--','linewidth',2);
plot(field(:,3),pVertical,'r','linewidth',2); hold on;
plot(field(:,3)-field(:,4),pVertical,'r--','linewidth',2);
plot(field(:,3)+field(:,4),pVertical,'r--','linewidth',2);
ylim([250 1000])
%text(1.4,320,'c','fontsize',14)
text(1.2,320,'c','fontsize',14)
set(gca, 'YDir', 'reverse' )
ylabel('pressure (hPa)')
xlabel('q (g/kg)')

axes(ha(4))
field = tVertical;
plot([0 0],[1000 250],'color',[.8 .8 .8],'linewidth',2); hold on;
plot(field(:,1),pVertical,'k','linewidth',2); hold on;
plot(field(:,1)-field(:,2),pVertical,'k--','linewidth',2);
plot(field(:,1)+field(:,2),pVertical,'k--','linewidth',2);
plot(field(:,3),pVertical,'r','linewidth',2); hold on;
plot(field(:,3)-field(:,4),pVertical,'r--','linewidth',2);
plot(field(:,3)+field(:,4),pVertical,'r--','linewidth',2);
ylim([250 1000])
%text(2.1,320,'d','fontsize',14)
text(1.3,320,'d','fontsize',14)
set(gca, 'YDir', 'reverse' )
xlabel('t (K)')

print('-dpng',['departuresVERTICAL_' num2str(startDate(1),'%.2i') num2str(startDate(2),'%.2i') '_'...
    num2str(endDate(1),'%.2i') num2str(endDate(2),'%.2i') '_' num2str(PRESSURE,'%.4i') '.png'])
print('-depsc',['departuresVERTICAL_' num2str(startDate(1),'%.2i') num2str(startDate(2),'%.2i') '_'...
    num2str(endDate(1),'%.2i') num2str(endDate(2),'%.2i') '_' num2str(PRESSURE,'%.4i') '.eps'])
    
%%    
figure
set(gcf,'Position',[70 50 900 650])
[ha, pos] = tight_subplot(2, 2, [.08 .06],[.1 .1],[.1 .1])

axes(ha(1))
field = uVertical;
plot(field(:,5),pVertical,'g','linewidth',2); hold on;
plot(field(:,5)+field(:,1),pVertical,'k','linewidth',2); hold on;
plot(field(:,5)+field(:,3),pVertical,'r','linewidth',2); hold on;
plot(field(:,5)+field(:,1)+field(:,2),pVertical,'k--','linewidth',2)
plot(field(:,5)+field(:,3)+field(:,4),pVertical,'r--','linewidth',2)
plot(field(:,5)+field(:,1)-field(:,2),pVertical,'k--','linewidth',2)
plot(field(:,5)+field(:,3)-field(:,4),pVertical,'r--','linewidth',2)
plot([0 0],[1000 250],'color',[.8 .8 .8],'linewidth',2)
ylim([250 1000])
%text(3,320,'a','fontsize',14)
text(8,320,'a','fontsize',14)
set(gca, 'YDir', 'reverse' )
ylabel('p (hPa)')
xlabel('u (m/s)')

axes(ha(2))
field = vVertical;
plot(field(:,5),pVertical,'g','linewidth',2); hold on;
plot(field(:,5)+field(:,1),pVertical,'k','linewidth',2); hold on;
plot(field(:,5)+field(:,3),pVertical,'r','linewidth',2); hold on;
plot(field(:,5)+field(:,1)+field(:,2),pVertical,'k--','linewidth',2)
plot(field(:,5)+field(:,3)+field(:,4),pVertical,'r--','linewidth',2)
plot(field(:,5)+field(:,1)-field(:,2),pVertical,'k--','linewidth',2)
plot(field(:,5)+field(:,3)-field(:,4),pVertical,'r--','linewidth',2)
plot([0 0],[1000 250],'color',[.8 .8 .8],'linewidth',2)
ylim([250 1000])
%text(5,320,'b','fontsize',14)
text(12,320,'b','fontsize',14)
set(gca, 'YDir', 'reverse' )
legend('OBS','YDPS','NDPS','location','northwest')
xlabel('v (m/s)')

axes(ha(3))
field = qVertical;
plot(field(:,5),pVertical,'g','linewidth',2); hold on;
plot(field(:,5)+field(:,1),pVertical,'k','linewidth',2); hold on;
plot(field(:,5)+field(:,3),pVertical,'r','linewidth',2); hold on;
plot(field(:,5)+field(:,1)+field(:,2),pVertical,'k--','linewidth',2)
plot(field(:,5)+field(:,3)+field(:,4),pVertical,'r--','linewidth',2)
plot(field(:,5)+field(:,1)-field(:,2),pVertical,'k--','linewidth',2)
plot(field(:,5)+field(:,3)-field(:,4),pVertical,'r--','linewidth',2)
plot([0 0],[1000 250],'color',[.8 .8 .8],'linewidth',2); hold on
ylim([250 1000])
set(gca, 'YDir', 'reverse' )
ylabel('p (hPa)')
xlabel('q (g/kg)')

axes(ha(4))
field = tVertical;
%plot([0 0],[1000 250],'color',[.8 .8 .8],'linewidth',2); hold on;
plot(field(:,5),pVertical,'g','linewidth',2); hold on;
plot(field(:,5)+field(:,1),pVertical,'k','linewidth',2); hold on;
plot(field(:,5)+field(:,3),pVertical,'r','linewidth',2); hold on;
plot(field(:,5)+field(:,1)+field(:,2),pVertical,'k--','linewidth',2)
plot(field(:,5)+field(:,3)+field(:,4),pVertical,'r--','linewidth',2)
plot(field(:,5)+field(:,1)-field(:,2),pVertical,'k--','linewidth',2)
plot(field(:,5)+field(:,3)-field(:,4),pVertical,'r--','linewidth',2)
ylim([250 1000])
set(gca, 'YDir', 'reverse' )
xlabel('t (K)')
    
%%
figure
set(gcf,'Position',[70 50 900 650])
[ha, pos] = tight_subplot(2, 2, [.08 .06],[.1 .1],[.1 .1])

axes(ha(1))
field = uVertical;
relK = abs(1-(field(:,5))./(field(:,5)+field(:,1)));
relR = abs(1-(field(:,5))./(field(:,5)+field(:,3)));
plot(relK,pVertical,'k','linewidth',2); hold on;
plot(relR,pVertical,'r','linewidth',2); hold on;
plot([0 0],[1000 250],'color',[.8 .8 .8],'linewidth',2)
ylim([250 1000])
set(gca, 'YDir', 'reverse' )
ylabel('pressure (hPa)')
xlabel('u (m/s)')

axes(ha(2))
field = vVertical;
relK = abs(1-(field(:,5))./(field(:,5)+field(:,1)));
relR = abs(1-(field(:,5))./(field(:,5)+field(:,3)));
plot(relK,pVertical,'k','linewidth',2); hold on;
plot(relR,pVertical,'r','linewidth',2); hold on;
ylim([250 1000])
set(gca, 'YDir', 'reverse' )
legend('CNTL','NODP','location','northwest')
xlabel('v (m/s)')

axes(ha(3))
field = qVertical;
relK = abs(1-(field(:,5))./(field(:,5)+field(:,1)));
relR = abs(1-(field(:,5))./(field(:,5)+field(:,3)));
plot(relK,pVertical,'k','linewidth',2); hold on;
plot(relR,pVertical,'r','linewidth',2); hold on;
ylim([250 1000])
set(gca, 'YDir', 'reverse' )
ylabel('pressure (hPa)')
xlabel('q (g/kg)')

axes(ha(4))
field = tVertical;
relK = abs(1-(field(:,5))./(field(:,5)+field(:,1)));
relR = abs(1-(field(:,5))./(field(:,5)+field(:,3)));
plot(relK,pVertical,'k','linewidth',2); hold on;
plot(relR,pVertical,'r','linewidth',2); hold on;
ylim([250 1000])
set(gca, 'YDir', 'reverse' )
xlabel('t (K)')


