%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% main3.m:                                                        %
% This script computes sf, ii, and dcin, and plots scatter plots. %
%                                                                 %
% Code written by:                                                %
%    Stipo Sentic (copyright 2021)                                %
%    Climate and Water consortium                                 %
%    New Mexico Tech                                              %
%    stipo (dot) sentic (at) nmt (dot) edu                        %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

clear all;
close all;
format shortG
global lonB latB

%[data; year mon day lon lat count Nsondes i Nlev pressure u v q T ];

dataCntl = load('cntl.txt');
dataNodp = load('nodps.txt');
dataCntl1 = dataCntl(dataCntl(:,4)>-100 & dataCntl(:,4)<-75 & dataCntl(:,3)>0 & dataCntl(:,3)<20 & dataCntl(:,7)==1,:);
dataNodp1 = dataNodp(dataNodp(:,4)>-100 & dataNodp(:,4)<-75 & dataNodp(:,3)>0 & dataNodp(:,3)<20 & dataNodp(:,7)==12,:);
% I suggest you use data values for which status = 1 in cntl and (at the same time) status = 12 in nodps

[dataU, dataV, dataT, dataQ] = getData(dataCntl1);
[dataUN, dataVN, dataTN, dataQN] = getData(dataNodp1);

pressures = [ 1000  950 925 900 850 800 700 600 500 400 300 250 ];
%pressures = 700;
lonB = -96.11111:1.11111:-75;
latB = 0:1.11111:16;

dates = unique(dataU(:,2:3),'rows');

%%
% find Q and T at the same point...
%for i = 1: length(dataQ)
%    
%end
dataQ_NEW = [];
dataT_NEW = [];
for i = 1:length(dataQ)
    f1 = dataQ(i,1:8);
    i2 = find(sum(abs(dataT(:,1:8)-f1),2)==0);
    if size(i2)>1 | size(i2)==0 | isempty(i2); continue; end
    dataQ_NEW = [dataQ_NEW; dataQ(i,:)];
    dataT_NEW = [dataT_NEW; dataT(i2,:)];
end
size(dataQ_NEW)
size(dataT_NEW)

dataQN_NEW = [];
dataTN_NEW = [];
for i = 1:length(dataQ_NEW)
    f1 = dataQ_NEW(i,1:8);
    j2 = find(sum(abs(dataQN(:,1:8)-f1),2)==0);
    i2 = find(sum(abs(dataTN(:,1:8)-f1),2)==0);
    if size(i2)>1 | size(j2)>1 | isempty(i2) | isempty(j2); continue; end
    dataQN_NEW = [dataQN_NEW; dataQN(j2,:)];
    dataTN_NEW = [dataTN_NEW; dataTN(i2,:)];
end
size(dataQN_NEW)
size(dataTN_NEW)

%
%calculate sf, ii, dcin for each drop
mrOBS = dataQ_NEW(:,11)./(1-dataQ_NEW(:,11));
tOBS = dataT_NEW(:,11);
pLEVELS = dataQ_NEW(:,8) * 100.0; % hPa to Pa
mrCNTL = (dataQ_NEW(:,11)+dataQ_NEW(:,12))./(1-dataQ_NEW(:,11)-dataQ_NEW(:,12));
tCNTL = dataT_NEW(:,11)+dataT_NEW(:,12);
satmrOBS = satmr(pLEVELS,tOBS);
satmrCNTL = satmr(pLEVELS,tCNTL);

entOBS = tOBS * NaN;
entCNTL = tCNTL * NaN;
satentOBS = tOBS * NaN;
satentCNTL = tCNTL * NaN;
for i = 1:length(dataQ_NEW)
    entOBS(i)  = ent(pLEVELS(i),tOBS(i),mrOBS(i));
    entCNTL(i)  = ent(pLEVELS(i),tCNTL(i),mrCNTL(i));    
    satentOBS(i)  = ent(pLEVELS(i),tOBS(i),satmrOBS(i));
    satentCNTL(i) = ent(pLEVELS(i),tCNTL(i),satmrCNTL(i));
end

mrN_OBS = dataQN_NEW(:,11)./(1-dataQN_NEW(:,11));
tN_OBS = dataTN_NEW(:,11);
pLEVELS = dataQN_NEW(:,8) * 100.0; % hPa to Pa
mrNODP = (dataQN_NEW(:,11)+dataQN_NEW(:,12))./(1-dataQN_NEW(:,11)-dataQN_NEW(:,12));
tNODP = dataTN_NEW(:,11)+dataTN_NEW(:,12);
satmrN_OBS = satmr(pLEVELS,tN_OBS);
satmrNODP = satmr(pLEVELS,tNODP);



entN_OBS = tN_OBS * NaN;
entNODP = tNODP * NaN;
satentN_OBS = tN_OBS * NaN;
satentNODP = tNODP * NaN;
for i = 1:length(dataQN_NEW)
    entN_OBS(i)  = ent(pLEVELS(i),tN_OBS(i),mrN_OBS(i));
    entNODP(i)  = ent(pLEVELS(i),tNODP(i),mrNODP(i));    
    satentN_OBS(i)  = ent(pLEVELS(i),tN_OBS(i),satmrN_OBS(i));
    satentNODP(i) = ent(pLEVELS(i),tNODP(i),satmrNODP(i));
end


%   1-3   4-5    7          6          8               9       10           11            12 
%	Date Time Latitude	 Longitude	Pressure (Pa)	Variable  Status	Observation  	Analysis departure

%                          9      10      11     12        13       14      15        16
data = [dataQ_NEW(:,1:8) mrOBS satmrOBS entOBS satentOBS mrCNTL satmrCNTL entCNTL satentCNTL];
dataN = [dataQN_NEW(:,1:8) mrN_OBS satmrN_OBS entN_OBS satentN_OBS mrNODP satmrNODP entNODP satentNODP];

%
uniqueDateandPos = unique(data(:,1:7),'rows');
dataSounding = [];
for i = 1:length(uniqueDateandPos)
    uniqueDateandPos(i,:)
    ind = find(sum(data(:,1:7)-uniqueDateandPos(i,:),2)==0);
    data00 = data(ind,:);
    iilow  = mean(data00(data00(:,8)<915 & data00(:,8)>685,:),1);
    iihigh = mean(data00(data00(:,8)<515 & data00(:,8)>385,:),1);
    dcinlow  = mean(data00(data00(:,8)>915,:),1);
    dcinhigh = mean(data00(data00(:,8)<865 & data00(:,8)>785,:),1);
    iiOBS = iilow(12) - iihigh(12);
    iiCNTL = iilow(16) - iihigh(16);
    dcinOBS = dcinhigh(12) - dcinlow(11);
    dcinCNTL = dcinhigh(16) - dcinlow(15);
    % satruration fraction 
    sfOBS = trapz(data00(:,8),data00(:,9))/ trapz(data00(:,8),data00(:,10));
    sfCNTL = trapz(data00(:,8),data00(:,13))/ trapz(data00(:,8),data00(:,14));
    
    ind = find(sum(dataN(:,1:7)-uniqueDateandPos(i,:),2)==0);
    data00 = dataN(ind,:);
    iilow  = mean(data00(data00(:,8)<915 & data00(:,8)>685,:),1);
    iihigh = mean(data00(data00(:,8)<515 & data00(:,8)>385,:),1);
    dcinlow  = mean(data00(data00(:,8)>915,:),1);
    dcinhigh = mean(data00(data00(:,8)<865 & data00(:,8)>785,:),1);
    iiOBS2 = iilow(12) - iihigh(12);
    iiNODP = iilow(16) - iihigh(16);
    dcinOBS2 = dcinhigh(12) - dcinlow(11);
    dcinNODP = dcinhigh(16) - dcinlow(15);
    % satruration fraction 
    sfOBS2 = trapz(data00(:,8),data00(:,9))/ trapz(data00(:,8),data00(:,10));
    sfNODP = trapz(data00(:,8),data00(:,13))/ trapz(data00(:,8),data00(:,14));
    
    
    dataSounding = [dataSounding; uniqueDateandPos(i,:) ...
        iiOBS iiOBS2 iiCNTL iiNODP...
        dcinOBS dcinOBS2 dcinCNTL dcinNODP...
        sfOBS sfOBS2 sfCNTL sfNODP...
        ];
end

%%
% 1-7               8    9      10     11
%dateandPos(i,:)  iiOBS iiOBS2 iiCNTL iiNODP...
%            12   13        14      15
%        dcinOBS dcinOBS2 dcinCNTL dcinNODP...
%          16   17      18     19
%        sfOBS sfOBS2 sfCNTL sfNODP...

figure
set(gcf,'Position',[70 50 1100 800])
[ha, pos] = tight_subplot(3, 2, [.05 .06],[.1 .1],[.1 .1])

x = dataSounding(:,8);  % iiOBS
y = dataSounding(:,10); % iiCNTL
z = dataSounding(:,11); % iiNODP
lim1 = -40;
lim2 = 80;
row = 0;
subplot(3,3,row+1)
plot(x,y,'r.'); hold on;
plot([lim1 lim2],[lim1 lim2],'k'); xlabel('II OBS (J/K/kg)'); ylabel('II CNTL (J/K/kg)')
plot([lim1 lim2],[0 0],'k'); plot([0 0],[lim1 lim2],'k'); xlim([lim1 lim2]); ylim([lim1 lim2])
subplot(3,3,row+2)
plot(x,z,'r.'); hold on;
plot([lim1 lim2],[lim1 lim2],'k'); xlabel('II OBS (J/K/kg)'); ylabel('II NODP (J/K/kg)')
plot([lim1 lim2],[0 0],'k'); plot([0 0],[lim1 lim2],'k'); xlim([lim1 lim2]); ylim([lim1 lim2])
subplot(3,3,row+3)
plot(y,z,'r.'); hold on;
plot([lim1 lim2],[lim1 lim2],'k'); xlabel('II CNTL (J/K/kg)'); ylabel('II NODP (J/K/kg)')
plot([lim1 lim2],[0 0],'k'); plot([0 0],[lim1 lim2],'k'); xlim([lim1 lim2]); ylim([lim1 lim2])

x = dataSounding(:,12);  % dcinOBS
y = dataSounding(:,14); % dcinCNTL
z = dataSounding(:,15); % dcinNODP
lim1 = -60;
lim2 = 150;
row = 3;
field = 'DCIN';
subplot(3,3,row+1)
plot(x,y,'r.'); hold on;
plot([lim1 lim2],[lim1 lim2],'k'); xlabel([field ' OBS (J/K/kg)']); ylabel([field ' CNTL (J/K/kg)'])
plot([lim1 lim2],[0 0],'k'); plot([0 0],[lim1 lim2],'k'); xlim([lim1 lim2]); ylim([lim1 lim2])
subplot(3,3,row+2)
plot(x,z,'r.'); hold on;
plot([lim1 lim2],[lim1 lim2],'k'); xlabel([field ' OBS (J/K/kg)']); ylabel([field ' NODP (J/K/kg)'])
plot([lim1 lim2],[0 0],'k'); plot([0 0],[lim1 lim2],'k'); xlim([lim1 lim2]); ylim([lim1 lim2])
subplot(3,3,row+3)
plot(y,z,'r.'); hold on;
plot([lim1 lim2],[lim1 lim2],'k'); xlabel([field ' CNTL (J/K/kg)']); ylabel([field ' NODP (J/K/kg)'])
plot([lim1 lim2],[0 0],'k'); plot([0 0],[lim1 lim2],'k'); xlim([lim1 lim2]); ylim([lim1 lim2])


x = dataSounding(:,16);  % sfOBS
y = dataSounding(:,18); % sfCNTL
z = dataSounding(:,19); % sfNODP
lim1 = 0.2;
lim2 = 1.2;
row = 6;
field = 'SF';
subplot(3,3,row+1)
plot(x,y,'r.'); hold on;
plot([lim1 lim2],[lim1 lim2],'k'); xlabel([field ' OBS']); ylabel([field ' CNTL'])
plot([lim1 lim2],[1 1],'b'); plot([1 1],[lim1 lim2],'b'); xlim([lim1 lim2]); ylim([lim1 lim2])
subplot(3,3,row+2)
plot(x,z,'r.'); hold on;
plot([lim1 lim2],[lim1 lim2],'k'); xlabel([field ' OBS']); ylabel([field ' NODP'])
plot([lim1 lim2],[1 1],'b'); plot([1 1],[lim1 lim2],'b'); xlim([lim1 lim2]); ylim([lim1 lim2])
subplot(3,3,row+3)
plot(y,z,'r.'); hold on;
plot([lim1 lim2],[lim1 lim2],'k'); xlabel([field ' CNTL']); ylabel([field ' NODP'])
plot([lim1 lim2],[1 1],'b'); plot([1 1],[lim1 lim2],'b'); xlim([lim1 lim2]); ylim([lim1 lim2])


print('-dpng',['thermodynamics.png'])
print('-dpng',['thermodynamics.eps'])


%%

figure
set(gcf,'Position',[70 50 600 800])
[ha, pos] = tight_subplot(3, 2, [.06 .08],[.1 .1],[.1 .1])

x = dataSounding(:,8);  % iiOBS
y = dataSounding(:,10); % iiCNTL
z = dataSounding(:,11); % iiNODP
lim1 = -40;
lim2 = 80;
axes(ha(3))
plot(x,y,'r.'); hold on;
plot([lim1 lim2],[lim1 lim2],'k'); xlabel('II OBS (J/K/kg)'); ylabel('II YDPS (J/K/kg)')
plot([lim1 lim2],[0 0],'k'); plot([0 0],[lim1 lim2],'k'); xlim([lim1 lim2]); ylim([lim1 lim2])
text(-30,65,'c','fontsize',14)
axes(ha(4))
plot(x,z,'r.'); hold on;
plot([lim1 lim2],[lim1 lim2],'k'); xlabel('II OBS (J/K/kg)'); ylabel('II NDPS (J/K/kg)')
plot([lim1 lim2],[0 0],'k'); plot([0 0],[lim1 lim2],'k'); xlim([lim1 lim2]); ylim([lim1 lim2])
text(-30,65,'d','fontsize',14)

x = dataSounding(:,12);  % dcinOBS
y = dataSounding(:,14); % dcinCNTL
z = dataSounding(:,15); % dcinNODP
lim1 = -60;
lim2 = 150;
field = 'DCIN';
axes(ha(5))
plot(x,y,'r.'); hold on;
plot([lim1 lim2],[lim1 lim2],'k'); xlabel([field ' OBS (J/K/kg)']); ylabel([field ' YDPS (J/K/kg)'])
plot([lim1 lim2],[0 0],'k'); plot([0 0],[lim1 lim2],'k'); xlim([lim1 lim2]); ylim([lim1 lim2])
text(-40,130,'e','fontsize',14)
axes(ha(6))
plot(x,z,'r.'); hold on;
plot([lim1 lim2],[lim1 lim2],'k'); xlabel([field ' OBS (J/K/kg)']); ylabel([field ' NDPS (J/K/kg)'])
plot([lim1 lim2],[0 0],'k'); plot([0 0],[lim1 lim2],'k'); xlim([lim1 lim2]); ylim([lim1 lim2])
text(-40,130,'f','fontsize',14)


x = dataSounding(:,16);  % sfOBS
y = dataSounding(:,18); % sfCNTL
z = dataSounding(:,19); % sfNODP
lim1 = 0.2;
lim2 = 1.2;
row = 6;
field = 'SF';
axes(ha(1))
plot(x,y,'r.'); hold on;
plot([lim1 lim2],[lim1 lim2],'k'); xlabel([field ' OBS']); ylabel([field ' YDPS'])
plot([lim1 lim2],[1 1],'b'); plot([1 1],[lim1 lim2],'b'); xlim([lim1 lim2]); ylim([lim1 lim2])
text(0.3,1.1,'a','fontsize',14)
axes(ha(2))
plot(x,z,'r.'); hold on;
plot([lim1 lim2],[lim1 lim2],'k'); xlabel([field ' OBS']); ylabel([field ' NDPS'])
plot([lim1 lim2],[1 1],'b'); plot([1 1],[lim1 lim2],'b'); xlim([lim1 lim2]); ylim([lim1 lim2])
text(0.3,1.1,'b','fontsize',14)


print('-dpng',['thermodynamics.png'])
print('-depsc',['thermodynamics.eps'])





    
