function plotlines()
sizeM = 15;
plot([-100 -65],[5 5],'k:','markersize',sizeM);
plot([-100 -65],[10 10],'k:','markersize',sizeM); 
plot([-100 -65],[15 15],'k:','markersize',sizeM); 

plot([-95 -95],[0 20],'k:','markersize',sizeM); 
plot([-90 -90],[0 20],'k:','markersize',sizeM); 
plot([-85 -85],[0 20],'k:','markersize',sizeM); 
plot([-80 -80],[0 20],'k:','markersize',sizeM); 
plot([-75 -75],[0 20],'k:','markersize',sizeM); 
plot([-70 -70],[0 20],'k:','markersize',sizeM); 
