#!/bin/sh
#
# lonlatdiv.sh -- Compute the 2-D divergence on a sphere.
# The units of divergence are the units of u and v divided by km.
#
if test $# != 5
then
    echo "Usage: lonlatdiv.sh lon lat u v div"
else
    lon=$1
    lat=$2
    u=$3
    v=$4
    div=$5

    a=111.2

    cdfmath "$v $lat cos * cv =" | \
	cdfderiv dudlon $u $lon | cdfderiv dcvdlat cv $lat | \
	cdfmath "dudlon dcvdlat + $a / $lat cos / $div =" | \
	cdfextr -r cv dudlon dcvdlat
fi
