function es = escalc(t)

A = 17.269;    %              /* constants for Tetens' formula */
B = 35.86;
C = 610.78;
D = 273.16;
LOOPOUT = 200;  %             /* max number of iteration loops */
QVMIN = 1.e-8;  %             /* smallest allowed mixing ratio */

CTOK = 273.15;              % /* Celsius to Kelvin conversion */
RD = 287.05;                %/* dry air gas constant */
EPS = 0.622;                % /* vapor to dry air mol weight ratio */
RV = (RD/EPS);              % /* water vapor gas constant */
CPD = 1005.;                % /* specific heat const pres dry air */
CPV = 1850.;                % /* specific heat const pres water vapor */
CL = 4218.;                 % /* specific heat liquid water */
CIMEAN = 1959.;             % /* specific heat of ice at -20 C */
LR = 2.5008e6;              % /* heat of vaporization at 0 C */
LFR = 3.337e5;              % /* heat of fusion at 0 C */
DLFDT = 2.45e3;             % /* slope of heat of fusion curve */
TR = 273.15;                % /* reference temperature (K) */
PR = 100000.;               % /* reference pressure (Pa) */
TMIN = 190.;                % /* minimum reasonable atmospheric temp */
GEE = 9.807;                % /* acceleration of gravity */
DELTA = 0.606;              % /* virtual temperature factor */


%float escalc(t)
  lr = LR;
  l = lr - (CL - CPV)*(t - TR);
  es = C*(TR./t).^((CL - CPV)/RV).*exp((lr/TR - l./t)/RV);



