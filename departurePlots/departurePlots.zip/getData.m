function [dataU, dataV, dataT, dataQ] = getData(data)

%	Date Time Latitude	 Longitude	Pressure (Pa)	Variable  Status	Observation  	Analysis departur

dateC = data(:,1);
yearC = floor(dateC/10000);
monC = floor((dateC-yearC*10000)/100);
dayC = dateC-yearC*10000-monC*100;
lon = data(:,4);
lat = data(:,3);
pressure = data(:,5)/100;
time = data(:,2);
hrC = NaN * data(:,2);
minC = NaN * data(:,2);
for i = 1: length(time)
    time1 = time(i);
    if time1>100000
        hr = floor(time1/10000);
        min = floor((time1-hr*10000)/100);
    elseif time1>10000
        hr = floor(time1/1000);
        min = floor((time1-hr*1000)/100);
    else
        i
        stop
    end
    hrC(i) = hr;
    minC(i) = min;
end
%   1-3   4-5    7          6          8               9       10           11            12 
%	Date Time Latitude	 Longitude	Pressure (Pa)	Variable  Status	Observation  	Analysis departure
data0 = [yearC monC dayC hrC minC lon lat pressure data(:,6:9)];

%variableName = {'u','v','T','q'};
%variableNumb = [3, 4, 2, 7];

dataU = data0(data0(:,9)==3,:);
dataV = data0(data0(:,9)==4,:);
dataT = data0(data0(:,9)==2,:);
dataQ = data0(data0(:,9)==7,:);



