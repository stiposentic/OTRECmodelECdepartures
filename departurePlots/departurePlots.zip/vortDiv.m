function [vort, div, Xd, Yd, Gamma, GammaA, VORT, DIV] = vortDiv(U,V,X,Y,positionsX,positionsY,DD,month,day)

%"$fx lat cos * cfx =" | \
%cdfderiv dcfxdlat cfx lat | cdfderiv dfydlon $fy lon | \
%cdfmath "dfydlon dcfxdlat - $a / lat cos / $curl =" | \
%cdfextr -r cfx dcfxdlat dfydlon

%cdfmath "$v $lat cos * cv =" | \
%cdfderiv dudlon $u $lon | cdfderiv dcvdlat cv $lat | \
%cdfmath "dudlon dcvdlat + $a / $lat cos / $div =" | \
%cdfextr -r cv dudlon dcvdlat

Ux = U .* cos(Y*pi/180);
dudy = (Ux(:,3:end) - Ux(:,1:end-2))./(Y(:,3:end) - Y(:,1:end-2));
dvdx = (V(3:end,:) - V(1:end-2,:))./(X(3:end,:) - X(1:end-2,:));
Xd = X(2:end-1,2:end-1);
Yd = Y(2:end-1,2:end-1);
dudy = dudy(2:end-1,:);
dvdx = dvdx(:,2:end-1);
vort = (dvdx - dudy)/111111./cos(Yd*pi/180);

Vx = V .* cos(Y*pi/180);
dudx = (U(3:end,:) - U(1:end-2,:))./(X(3:end,:) - X(1:end-2,:));
dvdy = (Vx(:,3:end) - Vx(:,1:end-2))./(Y(:,3:end) - Y(:,1:end-2));
Xd = X(2:end-1,2:end-1);
Yd = Y(2:end-1,2:end-1);
dudx = dudx(:,2:end-1);
dvdy = dvdy(2:end-1,:);
div = (dudx + dvdy)./(111111*cos(Yd*pi/180));

x = squeeze(positionsX);
y = squeeze(positionsY);
k = boundary(x,y);
        
mask = inpolygon(Xd,Yd,x(k),y(k));
[in,on] = inpolygon(Xd,Yd,x(k),y(k));
mask = in | on;
mask = double(mask);
mask(mask<=0.5) = NaN;

vort = vort .* mask;
div = div .* mask;

if month == 8 && day == 7        %DECAYING
    lon1 = -89;
    lat1 = 11;
    lon2 = -86;
    lat2 = 6;
    PLOTT = 0; 
    VORT = NaN; DIV = NaN; Gamma=NaN; GammaA=NaN; return;
elseif month == 8 && day == 11                   % DEVELOPING
    lon1 = -81;
    lat1 = 7;
    lon2 = -78;
    lat2 = 5.5;
    PLOTT = 0;
    %VORT = NaN; DIV = NaN; Gamma=NaN; GammaA=NaN; return;
elseif month == 8 && day == 12                   % DEVELOPING
    lon1 = -89;
    lat1 = 11;
    lon2 = -86;
    lat2 = 8;
    PLOTT = 0;
    %VORT = NaN; DIV = NaN; Gamma=NaN; GammaA=NaN; return;
elseif month == 8 && day == 16                   % DEVELOPING
    lon1 = -83;
    lat1 = 11;
    lon2 = -81;
    lat2 = 9;
    PLOTT = 0;
    %VORT = NaN; DIV = NaN; Gamma=NaN; GammaA=NaN; return;
elseif month == 8 && day == 17 %%%%%%%%%%%%%%%%%%%%%
    lon1 = -95;
    lat1 = 13;
    lon2 = -90.;
    lat2 = 10;
    PLOTT = 0;
    VORT = NaN; DIV = NaN; Gamma=NaN; GammaA=NaN; return;
elseif month == 8 && day == 18 %%%%%%%%%%%%%%%%%%%
    lon1 = -93;
    lat1 = 13.25;
    lon2 = -91.75;
    lat2 = 11.25;
    lon1 = -95;
    lat1 = 14;
    lon2 = -92;
    lat2 = 7;
    PLOTT = 0;
    %VORT = NaN; DIV = NaN; Gamma=NaN; GammaA=NaN; return;
elseif month == 8 && day == 22                   % DEVELOPING
    lon1 = -83;
    lat1 = 11.5;
    lon2 = -79.5;
    lat2 = 9.5;
    PLOTT = 0;
    %VORT = NaN; DIV = NaN; Gamma=NaN; GammaA=NaN; return;
elseif month == 8 && day == 23 %%%%%%%%%%%%%%%%%%%%
    lon1 = -88.5;
    lat1 = 6.25;
    lon2 = -86.5;
    lat2 = 3.5;
    PLOTT = 0;
    VORT = NaN; DIV = NaN; Gamma=NaN; GammaA=NaN; return;
elseif month == 8 && day == 25 %%%%%%%%%%%%%%%%
    lon1 = -80.75;
    lat1 = 6.0;
    lon2 = -78;
    lat2 = 4.25;
    PLOTT = 0;
    VORT = NaN; DIV = NaN; Gamma=NaN; GammaA=NaN; return;
elseif month == 9 && day == 3                   % DEVELOPING
    lon1 = -83.;
    lat1 = 11;
    lon2 = -79.5;
    lat2 = 9;
    PLOTT = 0;
    %VORT = NaN; DIV = NaN; Gamma=NaN; GammaA=NaN; return;
elseif month == 9 && day == 4 %%%%%%%%%%%%%%%%%%%%%%%
    lon1 = -89.;
    lat1 = 7.25;
    lon2 = -86.25;
    lat2 = 3.25;
    PLOTT = 0;
    VORT = NaN; DIV = NaN; Gamma=NaN; GammaA=NaN; return;
elseif month == 9 && day == 9  %%%%%%%%%%%%%%%%%%%%%
    lon1 = -81.;
    lat1 = 6.75;
    lon2 = -78.;
    lat2 = 5;
    PLOTT = 0;
    VORT = NaN; DIV = NaN; Gamma=NaN; GammaA=NaN; return;
elseif month == 9 && day ==17                   % DEVELOPING
    lon1 = -81.;
    lat1 = 7;
    lon2 = -78;
    lat2 = 4;
    PLOTT = 0;
    %VORT = NaN; DIV = NaN; Gamma=NaN; GammaA=NaN; return;
elseif month == 9 && day ==21     % DEVELOPING, but there is also a decaying one
    %developing
    lon1 = -89;
    lat1 = 9.5;
    lon2 = -86;
    lat2 = 7;
    %decaying
%      lon1 = -89;
%      lat1 = 12;
%      lon2 = -86;
%      lat2 = 10;
    PLOTT = 0;
elseif month == 9 && day ==22                   % DEVELOPING
    lon1 = -81;
    lat1 = 7;
    lon2 = -78;
    lat2 = 5.5;
    PLOTT = 0;
    %VORT = NaN; DIV = NaN; Gamma=NaN; GammaA=NaN; return;
elseif month == 9 && day ==24   %%%%%%%%%%%%%%%%%%%%
    lon1 = -88.75;
    lat1 = 9.75;
    lon2 = -87;
    lat2 = 3.25;
    PLOTT = 0;
    VORT = NaN; DIV = NaN; Gamma=NaN; GammaA=NaN; return;
elseif month == 9 && day ==25                   % DEVELOPING
    lon1 = -81;
    lat1 = 8;
    lon2 = -78;
    lat2 = 3.5;
    PLOTT = 0;
    %VORT = NaN; DIV = NaN; Gamma=NaN; GammaA=NaN; return;
elseif month == 9 && day ==27                   % DEVELOPING
    lon1 = -88.75;
    lat1 = 11;
    lon2 = -86.25;
    lat2 = 10;
    PLOTT = 0;
    %VORT = NaN; DIV = NaN; Gamma=NaN; GammaA=NaN; return;
elseif month == 9 && day ==28   % DECAYING
    lon1 = -89;
    lat1 = 10;
    lon2 = -86;
    lat2 = 6;
    PLOTT = 0;
    %VORT = NaN; DIV = NaN; Gamma=NaN; GammaA=NaN; return;
elseif month == 9 && day ==30                   % DEVELOPING
    lon1 = -89;
    lat1 = 6;
    lon2 = -86;
    lat2 = 3;
    PLOTT = 0;
    %VORT = NaN; DIV = NaN; Gamma=NaN; GammaA=NaN; return;
end



subplot(1,2,2)
set(gcf,'Position',[70 50 1100 800])
contourf(Xd,Yd,vort); hold on
plot(x,y,'k.')
plot([lon1 lon2],[lat1 lat1],'r','linewidth',2)
plot([lon1 lon2],[lat2 lat2],'r','linewidth',2)
plot([lon1 lon1],[lat1 lat2],'r','linewidth',2)
plot([lon2 lon2],[lat1 lat2],'r','linewidth',2)
axis equal
xlabel('longitude (deg)')
ylabel('latitude (deg)')
title(['Date: 2019-' num2str(month,'%.2i') '-' num2str(day,'%.2i')])

if PLOTT==1
    stop
end

% compute circulation in a box:
%   uppper
%  -------
%  |     |
%  |     |
% left   | right
%  |     |
%  |     |
%  -------
%   lower
    xC = [];
    yC = [];
    % lower
    x = (lon2-DD:-DD:lon1)';
    y = (x*0) + lat2;  xC = [xC; x]; yC = [yC; y];
    % left
    y = (lat2+DD:DD:lat1)';
    x = y*0 + lon1;    xC = [xC; x]; yC = [yC; y];
    % upper
    x = (lon1+DD:DD:lon2)';
    y = x*0 + lat1;    xC = [xC; x]; yC = [yC; y];
    % right
    y = (lat1-DD:-DD:lat2)';
    x = y*0 + lon2;    xC = [xC; x]; yC = [yC; y];
    VxC   = interp2(X',Y',U',xC,yC);
    VyC   = interp2(X',Y',V',xC,yC);
% % convert degrees to length in local cartesian coordinates in meters
    wgs84 = wgs84Ellipsoid;
    [xEast,yNorth,zUp] = geodetic2enu(yC,xC,xC*0,yC(1),xC(1),0,wgs84);
    xC = xEast;
    yC = yNorth;
    %     figure
%     plot(xC,yC,'k.','markersize',12)
%     xlabel('x (km)')
%     ylabel('y (km)')    
%     figure
%     plot(xEast,yNorth,'k.','markersize',12)
%     xlabel('x (km)')
%     ylabel('y (km)')
%     stop    
Gamma = -(trapz(xC,VxC) + trapz(yC,VyC));

R = 6371000.0; % Earth radius in meters
SUM = 0;
LON = lon1:DD:lon2;
LAT = lat1:-DD:lat2;
VORT = [];
DIV = [];
for i = 2:length(LON)-1
    for j = 2:length(LAT)-1
        lonS = LON(i);
        latS = LAT(j);
        [ii,jj] = find( Xd>lonS-0.01 & Xd<lonS+0.01 & ...
            Yd>latS-0.01 & Yd<latS+0.01);
        %AREA = areaquad(LON(i),LON(i+1),LAT(j),LAT(j+1))*4*pi*R^2;
        %SUM = SUM + ((vort(ii,jj)+vort(ii+1,jj)+...
        %    vort(ii,jj+1)+vort(ii+1,jj+1))/4000)*AREA;
        AREA = areaquad(Yd(ii,jj)-DD/2,Xd(ii,jj)-DD/2,...
                        Yd(ii,jj)+DD/2,Xd(ii,jj)+DD/2)...
                       *4*pi*R^2; %/111./111.;
        dSUM = vort(ii,jj)*AREA;
        
        if ~isnan(dSUM)
            SUM = SUM + dSUM;
            VORT = [VORT; vort(ii,jj)];
            DIV = [DIV; div(ii,jj)];
        else
            continue
        end       
    end
end
GammaA = SUM;
VORT = nanmean(VORT);
DIV = nanmean(DIV);













