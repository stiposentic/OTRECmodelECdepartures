%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% main2.m:                                                        %
% This script is similar to main.m, but the departures are        %
% plotted for each day individually.                              %
%                                                                 %
% main.m:                                                         %
% This script calculates the average horizontal departures in a   %
% range of dates. The user sets the date range after line 28.     %
% Here we also calculate vertical profiles of the departures on   %
% standard levels.                                                %
%                                                                 %
% Code written by:                                                %
%    Stipo Sentic (copyright 2021)                                %
%    Climate and Water consortium                                 %
%    New Mexico Tech                                              %
%    stipo (dot) sentic (at) nmt (dot) edu                        %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
clear all;
close all;
format shortG
global lonB latB

%[data; year mon day lon lat count Nsondes i Nlev pressure u v q T ];

dataCntl = load('cntl.txt');
dataNodp = load('nodps.txt');
dataCntl1 = dataCntl(dataCntl(:,4)>-100 & dataCntl(:,4)<-75 & dataCntl(:,3)>0 & dataCntl(:,3)<20 & dataCntl(:,7)==1,:);
dataNodp1 = dataNodp(dataNodp(:,4)>-100 & dataNodp(:,4)<-75 & dataNodp(:,3)>0 & dataNodp(:,3)<20 & dataNodp(:,7)==12,:);
% I suggest you use data values for which status = 1 in cntl and (at the same time) status = 12 in nodps

[dataU, dataV, dataT, dataQ] = getData(dataCntl1);
[dataUN, dataVN, dataTN, dataQN] = getData(dataNodp1);

pressures = [ 1000  950 925 900 850 800 700 600 500 400 300 250 ];
%pressures = 700;
lonB = -96.11111:1.11111:-75;
latB = 0:1.11111:16;

dates = unique(dataU(:,2:3),'rows');

figure
set(gcf,'Position',[70 50 1100 800])
        
dates = [8 18];
for dd = 1:size(dates,1)
    
    MONTH = dates(dd,1);
    DAY   = dates(dd,2);
    fprintf('Working on date: %.2i-%.2i\n', MONTH, DAY)
    
    for ii = 1:length(pressures)
        
        PRESSURE = pressures(ii);
        fprintf('Working on pressure: %4.0f\n',PRESSURE)
        
        clf % clear figure content
        MAPPING = 1;
        
        for FIELD = 1:4
            
            
            if FIELD == 1
                fieldName = 'u';
                n = 11;
                nx = 18;
                data = dataU;
                dataN = dataUN;
                multiplier = 1;
                offset = 0;
            end
            
            if FIELD == 2
                fieldName = 'v';
                n = 14;
                nx = 19;
                data = dataV;
                dataN = dataVN;
                multiplier = 1;
                offset = 0;
            end
            
            if FIELD == 3
                fieldName = 'q';
                n = 11;
                nx = 16;
                data = dataQ;
                dataN = dataQN;
                multiplier = 1000;
                offset = 0;
            end
            
            if FIELD == 4
                fieldName = 'T';
                n = 11;
                nx = 17;
                data = dataT;
                dataN = dataTN;
                multiplier = 1;
                offset = 0;
            end
            
            %select only one date
            data = data(data(:,2)==MONTH & data(:,3)==DAY,:);
            dataN = dataN(dataN(:,2)==MONTH & dataN(:,3)==DAY,:);
            
            number = NaN(length(lonB),length(latB),12);
            numberN = NaN(length(lonB),length(latB),12);
            
            
            dataPres = data(data(:,8)>PRESSURE-15 & data(:,8)<PRESSURE+15,:);
            dataPresN = dataN(dataN(:,8)>PRESSURE-15 & dataN(:,8)<PRESSURE+15,:);
            
            departures = NaN(length(lonB),length(latB),8000);
            field = NaN(length(lonB),length(latB),8000);
            departuresN = NaN(length(lonB),length(latB),8000);
            fieldN = NaN(length(lonB),length(latB),8000);
            
            for jj = 1:size(dataPres,1)
                lons = dataPres(jj,6);
                lats = dataPres(jj,7);
                if lons<-96 || lons>-75
                    continue
                end
                if lats<0 || lats>15
                    continue
                end
                if ~isnan(lons)
                    [i,j] = lonlat(lons,lats);
                    field(i,j,jj) = dataPres(jj,11)*multiplier+offset;
                    departures(i,j,jj) = dataPres(jj,12)*multiplier;
                end
            end
            for jj = 1:size(dataPresN,1)
                lons = dataPresN(jj,6);
                lats = dataPresN(jj,7);
                if lons<-96 || lons>-75
                    continue
                end
                if lats<0 || lats>15
                    continue
                end
                if ~isnan(lons)
                    [i,j] = lonlat(lons,lats);
                    fieldN(i,j,jj) = dataPresN(jj,11)*multiplier+offset;
                    departuresN(i,j,jj) = dataPresN(jj,12)*multiplier;
                end
            end
            
            %departures(1:2,:)
            %departuresN(1:2,:)
            %var4(1:2,:)
            
            dep = nanmean(departures,3);
            var4 = nanmean(field,3);
            depN = nanmean(departuresN,3);
            var4N = nanmean(fieldN,3);
            
            
            Ndep = nansum(departures*0+1,3);
            Nvar = nansum(field*0+1,3);
            NdepN = nansum(departuresN*0+1,3);
            NvarN = nansum(fieldN*0+1,3);
            
            rmsDep = sqrt((1./Ndep).*(nansum(departures.^2,3)));
            rmsVar = sqrt((1./Nvar).*(nansum(field.^2,3)));
            rmsDepN = sqrt((1./NdepN).*(nansum(departuresN.^2,3)));
            rmsVarN = sqrt((1./NvarN).*(nansum(fieldN.^2,3)));
            
            number(:,:,ii) = Ndep;
            numberN(:,:,ii) = NdepN;
            
            numm = nansum(number,3);
            nummN = nansum(numberN,3);
            
            %[nanmean(var4(:)) max(var4(:)) min(var4(:))]
            %[nanmean(dep(:)) max(dep(:)) min(dep(:))]
            
            
            %         map =  [ 69.0 56.9 100.0; ...
            %             56.9 67.1 100; ...
            %             56.9 90.2 100.0; ...
            %             61.2 83.1 71.0; ...
            %             100 100 71; ...
            %             99.2 78.0 49.8; ...
            %             98 43.9 40]...
            %             /100.0;
            
            
            load coastlines
            
            if FIELD == 4
                addon = -nanmean(var4(:)) ;
            else
                addon = 0;
            end
            
            ax(0+FIELD) = subplot(3,4,0+FIELD);
            c = pcolor (lonB,latB,var4'+addon); hold on; plotlines;
            plot(coastlon,coastlat,'k')
            set(c,'EdgeColor','none');
            cb = colorbar('location','northoutside');
            if FIELD == 1 & MAPPING == 1
                caxis([-12 9]) % sets colorbar limits
                set(cb,'xtick',[-12 -9 -6 -3 0 3 6 9])
            end
            if FIELD == 2 & MAPPING == 1
                caxis([-6 9]) % sets colorbar limits
                set(cb,'xtick',[-6 -3 0 3 6 9])
            end
            if FIELD == 3 & MAPPING == 1
                caxis([2 12]) % sets colorbar limits
                set(cb,'xtick',[2 4 6 8 10 12])
            end
            if FIELD == 4 & MAPPING == 1
                caxis([-2 2]) % sets colorbar limits
                set(cb,'xtick',[-2 -1 0 1 2])
            end
            axis equal
            xlim([-100 -65])
            ylim([0 20])
            title([fieldName ', OBS'])
            
            
            ax(4+FIELD) = subplot(3,4,4+FIELD);
            c = pcolor (lonB,latB,dep'); hold on; plotlines;
            plot(coastlon,coastlat,'k')
            set(c,'EdgeColor','none');
            cb = colorbar('location','northoutside');
            if FIELD == 0
                caxis([-7 7]) % sets colorbar limits
                set(cb,'xtick',[-7 -5 -3 -1 1 3 5 7])
            end
            
            if FIELD == 1 & MAPPING == 1
                caxis([-7 7]) % sets colorbar limits
                set(cb,'xtick',[-7 -5 -3 -1 1 3 5 7])
            end
            if FIELD == 2 & MAPPING == 1
                caxis([-11 7]) % sets colorbar limits
                set(cb,'xtick',[-11 -9 -7 -5 -3 -1 1 3 5 7])
            end
            if FIELD == 3 & MAPPING == 1
                caxis([-2.5 3.5]) % sets colorbar limits
                set(cb,'xtick',[-2.5 -1.5 -0.5 0.5 1.5 2.5 3.5])
            end
            if FIELD == 4 & MAPPING == 1
                caxis([-2 2]) % sets colorbar limits
                set(cb,'xtick',[-2 -1.5 -0.5 0.5 1.5 2])
            end
            axis equal
            xlim([-100 -65])
            ylim([0 20])
            title([fieldName  ', CNTL departures'])
            
            ax(8+FIELD) = subplot(3,4,8+FIELD);
            c = pcolor (lonB,latB,depN'); hold on; plotlines;
            plot(coastlon,coastlat,'k')
            set(c,'EdgeColor','none');
            cb = colorbar('location','northoutside');
            if FIELD == 0
                caxis([-7 7]) % sets colorbar limits
                set(cb,'xtick',[-7 -5 -3 -1 1 3 5 7])
            end
            
            if FIELD == 1 & MAPPING == 1
                %caxis([-9 5]) % sets colorbar limits
                %set(cb,'xtick',[-9 -7 -5 -3 -1 1 3 5])
                caxis([-7 7]) % sets colorbar limits
                set(cb,'xtick',[-7 -5 -3 -1 1 3 5 7])
                
            end
            if FIELD == 2 & MAPPING == 1
                caxis([-11 7]) % sets colorbar limits
                set(cb,'xtick',[-11 -9 -7 -5 -3 -1 1 3 5 7])
            end
            if FIELD == 3 & MAPPING == 1
                caxis([-2.5 3.5]) % sets colorbar limits
                set(cb,'xtick',[-2.5 -1.5 -0.5 0.5 1.5 2.5 3.5])
                
            end
            if FIELD == 4 & MAPPING == 1
                caxis([-2 2]) % sets colorbar limits
                set(cb,'xtick',[-2 -1.25 -0.5 0.5 1.25 2])
            end
            axis equal
            xlim([-100 -65])
            ylim([0 20])
            title([fieldName  ', NODPS departures'])
        end
        
        ax(1);
        ax(2);
        
        if MAPPING == 1
            mappingColors
            colormap(ax(1),map1)
            colormap(ax(2),map2)
            colormap(ax(3),map3)
            colormap(ax(4),map4)
            
            colormap(ax(5),map5)
            colormap(ax(6),map6)
            colormap(ax(7),map7)
            colormap(ax(8),map8)
            
            colormap(ax(9),map9)
            colormap(ax(10),map10)
            colormap(ax(11),map11)
            colormap(ax(12),map12)
        end
        
        subplot(3,4,1)
        text(-50,40,['Date: ' num2str(MONTH,'%.2i') '-' num2str(DAY,'%.2i') ', pressure: ' num2str(PRESSURE) ' hPa'],'fontsize',14)
        
        %print('-dpng',['INDIVdepartures_' num2str(MONTH,'%.2i') num2str(DAY,'%.2i') '_' num2str(PRESSURE,'%.4i') '.png'])
    end %pressures
end %dates

% dataT_NEW = [];
% dataTN_NEW = [];
% dataQ_NEW = [];
% for i = 1:length(dataU)
%     f1 = dataU(i,1:8);
%     i2 = find(sum(dataT(:,1:8)-f1)==0); if i2>1; stop; end
%     dataT_NEW = [dataT_NEW; dataT(i2,:)];
%     i2 = find(sum(dataTN(:,1:8)-f1)==0);if i2>1; stop; end
%     dataTN_NEW = [dataTN_NEW; dataTN(i2,:)];
%     i2 = find(sum(dataQN(:,1:8)-f1)==0);if i2>1; stop; end
%     dataQN_NEW = [dataQN_NEW; dataQN(i2,:)];
% end
% %%
% dataQ_NEW = [];
% for i = 1:length(dataU)
%     f1 = dataU(i,1:8);
%     i2 = find(sum(dataQ(:,1:8)-f1)==0);if i2>1 || i2==0; stop; end
%     dataQ_NEW = [dataQ_NEW; dataQ(i2,:)];
% end
% dataQN_NEW = [];
% for i = 1:length(dataQ)
%     f1 = dataQ(i,1:8);
%     i2 = find(sum(dataQN(:,1:8)-f1)==0);if i2>1 || i2==0; stop; end
%     dataQN_NEW = [dataQN_NEW; dataQN(i2,:)];
% end
% stop
% %%
% tmp = (dataU(:,1:8)-dataUN(:,1:8));
% sum(tmp(:))
% tmp = (dataV(:,1:8)-dataVN(:,1:8));
% sum(tmp(:))
% tmp = (dataQ_NEW(:,1:8)-dataQN_NEW(:,1:8));
% dataQ_NEW(1:5,:)
% dataQN_NEW(1:5,:)
% tmp(1:5,:)
% %sum(tmp,2)
% %%
% tmp = (dataT_NEW(:,1:8)-dataTN_NEW(:,1:8));
% sum(tmp(:))

%   1    2   3   4  5    6   7   8     9         10     11              12
%	year mon day hr min  lon lat pres  Variable  Status	Observation  	Analysis departure







