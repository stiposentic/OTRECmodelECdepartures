%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% main4.m:                                                        %
% This script compares vertical departures with sattelite         %
% brightness.                                                     %
%                                                                 %
% Code written by:                                                %
%    Stipo Sentic (copyright 2021)                                %
%    Climate and Water consortium                                 %
%    New Mexico Tech                                              %
%    stipo (dot) sentic (at) nmt (dot) edu                        %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

clear all;
close all;
format shortG
global lonB latB

%[data; year mon day lon lat count Nsondes i Nlev pressure u v q T ];

dataCntl = load('cntl.txt');
dataNodp = load('nodps.txt');
dataCntl1 = dataCntl(dataCntl(:,4)>-100 & dataCntl(:,4)<-75 & dataCntl(:,3)>0 & dataCntl(:,3)<20 & dataCntl(:,7)==1,:);
dataNodp1 = dataNodp(dataNodp(:,4)>-100 & dataNodp(:,4)<-75 & dataNodp(:,3)>0 & dataNodp(:,3)<20 & dataNodp(:,7)==12,:);
% I suggest you use data values for which status = 1 in cntl and (at the same time) status = 12 in nodps

[dataU, dataV, dataT, dataQ] = getData(dataCntl1);
[dataUN, dataVN, dataTN, dataQN] = getData(dataNodp1);

pressures = [ 1000  950 925 900 850 800 700 600 500 400 300 250 ];
%pressures = 700;
lonB = -96.11111:1.11111:-75;
latB = 0:1.11111:16;

%%
SAT_AVE = 0.25; % 1 degree box
load depBright_0.25.mat

% data = dataU; dataSoundingU = departureBrightness(SAT_AVE,data,'1');
% data = dataV; dataSoundingV = departureBrightness(SAT_AVE,data,'2');
% data = dataT; dataSoundingT = departureBrightness(SAT_AVE,data,'3');
% data = dataQ; dataSoundingQ = departureBrightness(SAT_AVE,data,'4');
% 
 data = dataUN; dataSoundingUN = departureBrightness(SAT_AVE,data,'5');
% data = dataVN; dataSoundingVN = departureBrightness(SAT_AVE,data,'6');
% data = dataTN; dataSoundingTN = departureBrightness(SAT_AVE,data,'7');
% data = dataQN; dataSoundingQN = departureBrightness(SAT_AVE,data,'8');
% 
% save(['depBright_' num2str(SAT_AVE,'%4.2f') '.mat'], ...
%     'dataSoundingU', 'dataSoundingV', 'dataSoundingQ', 'dataSoundingT',...
%     'dataSoundingUN', 'dataSoundingVN', 'dataSoundingQN', 'dataSoundingTN');



%%
% 1-7               8                   9           10                11
%dateandPos(i,:)  verticalDeparture BRIGHTNESS maxDeparturePressure maxDep
figure
set(gcf,'Position',[70 50 800 600])
[ha, pos] = tight_subplot(2, 2, [.05 .06],[.1 .1],[.1 .1])

pointMarkerSize = 8;
lineWidth = 2;

%subplot(2,2,1)
axes(ha(1))
dataSounding = dataSoundingU(dataSoundingU(:,9)<1000,:);
y = dataSounding(:,8); x = dataSounding(:,9); X = [ones(length(x),1) x]; b = X\y; yCalc2 = X*b;
plot(x,y,'k.','markersize',pointMarkerSize); hold on;
dataSounding = dataSoundingUN(dataSoundingUN(:,9)<1000,:);
y = dataSounding(:,8); x = dataSounding(:,9); X = [ones(length(x),1) x]; b = X\y; yCalc3 = X*b;
plot(x,y,'r.','markersize',pointMarkerSize); 
plot(x,yCalc2,'k','linewidth',lineWidth)
plot(x,yCalc3,'r','linewidth',lineWidth)
ylabel('u* (m/s)');
legend('YDPS','NDPS','location','northwest')
text(240,9,'a','fontsize',14)

%subplot(2,2,2)
axes(ha(2))
dataSounding = dataSoundingV(dataSoundingV(:,9)<1000,:);
y = dataSounding(:,8); x = dataSounding(:,9); X = [ones(length(x),1) x]; b = X\y; yCalc2 = X*b;
plot(x,y,'k.','markersize',pointMarkerSize); hold on;
dataSounding = dataSoundingVN(dataSoundingVN(:,9)<1000,:);
y = dataSounding(:,8); x = dataSounding(:,9); X = [ones(length(x),1) x]; b = X\y; yCalc3 = X*b;
plot(x,y,'r.','markersize',pointMarkerSize); 
plot(x,yCalc2,'k','linewidth',lineWidth)
plot(x,yCalc3,'r','linewidth',lineWidth)
ylabel('v* (m/s)');
text(210,9,'b','fontsize',14)

%subplot(2,2,3)
axes(ha(3))
dataSounding = dataSoundingQ(dataSoundingQ(:,9)<1000,:);
y = dataSounding(:,8)*1000; x = dataSounding(:,9); X = [ones(length(x),1) x]; b = X\y; yCalc2 = X*b;
plot(x,y,'k.','markersize',pointMarkerSize); hold on;
dataSounding = dataSoundingQN(dataSoundingQN(:,9)<1000,:);
y = dataSounding(:,8)*1000; x = dataSounding(:,9); X = [ones(length(x),1) x]; b = X\y; yCalc3 = X*b;
plot(x,y,'r.','markersize',pointMarkerSize); 
plot(x,yCalc2,'k','linewidth',lineWidth)
plot(x,yCalc3,'r','linewidth',lineWidth)
xlabel('T_B (K)');
ylabel('q* (g/kg)');
ylim([0 3.5])
text(208,3.2,'c','fontsize',14)

%subplot(2,2,4)
axes(ha(4))
dataSounding = dataSoundingT(dataSoundingT(:,9)<1000,:);
y = dataSounding(:,8); x = dataSounding(:,9); X = [ones(length(x),1) x]; b = X\y; yCalc2 = X*b;
plot(x,y,'k.','markersize',pointMarkerSize); hold on;
dataSounding = dataSoundingTN(dataSoundingTN(:,9)<1000,:);
y = dataSounding(:,8); x = dataSounding(:,9);X = [ones(length(x),1) x]; b = X\y; yCalc3 = X*b;
plot(x,y,'r.','markersize',pointMarkerSize); 
plot(x,yCalc2,'k','linewidth',lineWidth)
plot(x,yCalc3,'r','linewidth',lineWidth)
xlabel('T_B (K)');
ylabel('T* (K)');
ylim([0 3.5])
text(208,3.2,'d','fontsize',14)

print('-dpng',['departuresBrighness_' num2str(SAT_AVE,'%4.2f') '.png'])
print('-depsc',['departuresBrighness_' num2str(SAT_AVE,'%4.2f') '.eps'])


%%
% 1-7               8                   9           10                11
%dateandPos(i,:)  verticalDeparture BRIGHTNESS maxDeparturePressure maxDep
figure
set(gcf,'Position',[70 50 800 600])
[ha, pos] = tight_subplot(2, 2, [.08 .06],[.1 .1],[.1 .1]);

column1 = 10; %x
column2 = 11; %y
XLABEL = 'pressure of max. departure (hPa)';
YLABEL = 'max. departure';
pointMarkerSize = 8;
lineWidth = 2;

%subplot(2,2,1)
axes(ha(1))
dataSounding = dataSoundingU;
y = dataSounding(:,column2); x = dataSounding(:,column1); X = [ones(length(x),1) x]; b = X\y; yCalc2 = X*b;
plot(x,y,'k.','markersize',pointMarkerSize); hold on;
dataSounding = dataSoundingUN;
y = dataSounding(:,column2); x = dataSounding(:,column1); X = [ones(length(x),1) x]; b = X\y; yCalc3 = X*b;
plot(x,y,'r.','markersize',pointMarkerSize); 
%plot(x,yCalc2,'k','linewidth',lineWidth)
%plot(x,yCalc3,'r','linewidth',lineWidth)
title('u (m/s)');
ylabel(YLABEL)
legend('CNTL','NODP','location','northeast')
xlim([100 1100])

%subplot(2,2,2)
axes(ha(2))
dataSounding = dataSoundingV;
y = dataSounding(:,column2); x = dataSounding(:,column1); X = [ones(length(x),1) x]; b = X\y; yCalc2 = X*b;
plot(x,y,'k.','markersize',pointMarkerSize); hold on;
dataSounding = dataSoundingVN;
y = dataSounding(:,column2); x = dataSounding(:,column1); X = [ones(length(x),1) x]; b = X\y; yCalc3 = X*b;
plot(x,y,'r.','markersize',pointMarkerSize); 
%plot(x,yCalc2,'k','linewidth',lineWidth)
%plot(x,yCalc3,'r','linewidth',lineWidth)
title('v (m/s)');
xlim([100 1100])

%subplot(2,2,3)
axes(ha(3))
dataSounding = dataSoundingQ;
y = dataSounding(:,column2)*1000; x = dataSounding(:,column1); X = [ones(length(x),1) x]; b = X\y; yCalc2 = X*b;
plot(x,y,'k.','markersize',pointMarkerSize); hold on;
dataSounding = dataSoundingQN;
y = dataSounding(:,column2)*1000; x = dataSounding(:,column1); X = [ones(length(x),1) x]; b = X\y; yCalc3 = X*b;
plot(x,y,'r.','markersize',pointMarkerSize); 
%plot(x,yCalc2,'k','linewidth',lineWidth)
%plot(x,yCalc3,'r','linewidth',lineWidth)
xlabel(XLABEL);
title('q (g/kg)');
ylabel(YLABEL)
%ylim([0 3.5])
xlim([100 1100])

%subplot(2,2,4)
axes(ha(4))
dataSounding = dataSoundingT;
y = dataSounding(:,column2); x = dataSounding(:,column1); X = [ones(length(x),1) x]; b = X\y; yCalc2 = X*b;
plot(x,y,'k.','markersize',pointMarkerSize); hold on;
dataSounding = dataSoundingTN;
y = dataSounding(:,column2); x = dataSounding(:,column1);X = [ones(length(x),1) x]; b = X\y; yCalc3 = X*b;
plot(x,y,'r.','markersize',pointMarkerSize); 
%plot(x,yCalc2,'k','linewidth',lineWidth)
%plot(x,yCalc3,'r','linewidth',lineWidth)
xlabel(XLABEL);
title('T (K)');
ylim([0 8])
xlim([100 1100])

print('-dpng',['departuresBrighnessMax_' num2str(SAT_AVE,'%4.2f') '.png'])





    
