
load singleYDP.mat;
figure
set(gcf,'Position',[70 50 400 500])
plot(OBS,pres,'k','linewidth',2); hold on;
plot(EXPE,pres,'r','linewidth',2); hold on;
load singleNDP.mat;
plot(EXPE,pres,'b','linewidth',2); hold on;
plot(EXPE*0,pres,'k--'); hold on;
set(gca, 'YDir','reverse')
xlabel('zonal wind (m/s)')
ylabel('pressure (hPa)')
%legend('OBS','NODP')
%title(['2019/' mm '/' dd ', ' hh ':' min ', u* =  ' num2str(verticalDeparture,'%4.1f') ' (m/s)'])
%print('-dpng',['NDPdeparture_' mm dd hh min '.png'])
set(gca,'fontsize',12)



load singleYDP_0818_1712.mat;
figure
set(gcf,'Position',[70 50 400 500])
plot(OBS,pres,'k','linewidth',2); hold on;
plot(EXPE,pres,'r','linewidth',2); hold on;
load singleNDP_0818_1712.mat;
plot(EXPE,pres,'b','linewidth',2); hold on;
plot(EXPE*0,pres,'k--'); hold on;
set(gca, 'YDir','reverse')
xlabel('zonal wind (m/s)')
ylabel('pressure (hPa)')
%legend('OBS','NODP')
title(['2019/08/18, 17:12'])
print('-dpng','PLOTdeparture_0818_1712.png')
set(gca,'fontsize',12)


load singleYDP_0818_1435.mat;
figure
set(gcf,'Position',[70 50 400 500])
plot(OBS,pres,'k','linewidth',2); hold on;
plot(EXPE,pres,'r','linewidth',2); hold on;
load singleNDP_0818_1435.mat;
plot(EXPE,pres,'b','linewidth',2); hold on;
plot(EXPE*0,pres,'k--'); hold on;
set(gca, 'YDir','reverse')
xlabel('zonal wind (m/s)')
ylabel('pressure (hPa)')
%legend('OBS','NODP')
title('2019/08/18, 14:35')
print('-dpng','PLOTdeparture_0818_1435.png')
set(gca,'fontsize',12)
