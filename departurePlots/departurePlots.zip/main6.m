%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% main6.m:                                                        %
% This script is similar to main2.m, but it is used to estimate   % 
% vorticity departures. We calculate/estimate vorticity with      %
% observations, CNTL, and NODP data for each pressure level.      %
%                                                                 %
% Code written by:                                                %
%    Stipo Sentic (copyright 2021)                                %
%    Climate and Water consortium                                 %
%    New Mexico Tech                                              %
%    stipo (dot) sentic (at) nmt (dot) edu                        %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

clear all;
close all;
format shortG
global lonB latB lonBT latBT

%[data; year mon day lon lat count Nsondes i Nlev pressure u v q T ];

dataCntl = load('cntl.txt');
dataNodp = load('nodps.txt');
dataCntl1 = dataCntl(dataCntl(:,4)>-100 & dataCntl(:,4)<-75 & ...
    dataCntl(:,3)>0 & dataCntl(:,3)<20 & dataCntl(:,7)==1,:);
dataNodp1 = dataNodp(dataNodp(:,4)>-100 & dataNodp(:,4)<-75 & ...
    dataNodp(:,3)>0 & dataNodp(:,3)<20 & dataNodp(:,7)==12,:);
% I suggest you use data values for which status = 1 in cntl and 
% (at the same time) status = 12 in nodps

[dataU, dataV, dataT, dataQ] = getData(dataCntl1);
[dataUN, dataVN, dataTN, dataQN] = getData(dataNodp1);

pressures = [ 1000  950 925 900 850 800 700 600 500 400 300 250 ];
%pressures = 700;
lonB = -96.11111:1.11111:-75;
latB = 0:1.11111:16;


DEGREES = 0.25;


dates = unique(dataU(:,2:3),'rows');
dates = [8 18];
lonBT = -96:DEGREES:-75;
latBT = 0:DEGREES:16;
[X,Y] = meshgrid(lonBT,latBT);

VORTICITYO = NaN(size(X',1)-2,size(X',2)-2,12,size(dates,1));
DIVERGENCO = NaN(size(X',1)-2,size(X',2)-2,12,size(dates,1));
VORTICITYC = VORTICITYO;
DIVERGENCC = DIVERGENCO;
VORTICITYN = VORTICITYO;
DIVERGENCN = DIVERGENCO;

GammaO_F = NaN(12,22);
GammaC_F = NaN(12,22);
GammaN_F = NaN(12,22);
GammaAO_F = NaN(12,22);
GammaAC_F = NaN(12,22);
GammaAN_F = NaN(12,22);

VORTO_F = NaN(12,22);
VORTC_F = NaN(12,22);
VORTN_F = NaN(12,22);
DIVO_F = NaN(12,22);
DIVC_F = NaN(12,22);
DIVN_F = NaN(12,22);
    
figure
set(gcf,'Position',[70 50 1100 800])
       % dates = [8 18];
for dd = 1:size(dates,1)
    MONTH = dates(dd,1);
    DAY   = dates(dd,2);
    fprintf('Working on date: %.2i-%.2i\n', MONTH, DAY)
    
    if MONTH == 8 && DAY == 19
        continue
    end
    if MONTH == 8 && DAY == 20
        continue
    end
    
    GammaO_N = [];
    GammaC_N = [];
    GammaN_N = [];
    GammaAO_N = [];
    GammaAC_N = [];
    GammaAN_N = [];
    p=[];
    VORTO_N = [];
    VORTC_N = [];
    VORTN_N = [];
    DIVO_N = [];
    DIVC_N = [];
    DIVN_N = [];
    
    for ii = 1:length(pressures)
        PRESSURE = pressures(ii);
        fprintf('Working on pressure: %4.0f\n',PRESSURE)
        
        %clf % clear figure content
        %MAPPING = 1;

        data = dataU;
        dataN = dataUN;
        %select only one date
        data = data(data(:,2)==MONTH & data(:,3)==DAY,:);
        dataN = dataN(dataN(:,2)==MONTH & dataN(:,3)==DAY,:);
        dataPresU = data(data(:,8)>PRESSURE-15 & data(:,8)<PRESSURE+15,:);
        dataPresUN = dataN(dataN(:,8)>PRESSURE-15 & dataN(:,8)<PRESSURE+15,:);
        % get unique positions of drops with obs data and CNTL data
        [positionsU, U, UC] = dataPositions(dataPresU);
        [positionsUN, Utmp, UN] = dataPositions(dataPresUN);
        
%         figure
%         contourf(X,Y,U); hold on
%         plot(positionsU(:,1),positionsU(:,2),'k.')
%         figure
%         contourf(X,Y,UN); hold on
%         plot(positionsUN(:,1),positionsUN(:,2),'k.')
        
        data = dataV;
        dataN = dataVN;
        %select only one date
        data = data(data(:,2)==MONTH & data(:,3)==DAY,:);
        dataN = dataN(dataN(:,2)==MONTH & dataN(:,3)==DAY,:);
        dataPresV = data(data(:,8)>PRESSURE-15 & data(:,8)<PRESSURE+15,:);
        dataPresVN = dataN(dataN(:,8)>PRESSURE-15 & dataN(:,8)<PRESSURE+15,:);
        % get unique positions of drops with obs data and CNTL data
        [positionsV, V, VC] = dataPositions(dataPresV);
        [positionsVN, Vtmp, VN] = dataPositions(dataPresVN);
        
%         figure
%         contourf(X,Y,V); hold on
%         plot(positionsV(:,1),positionsV(:,2),'k.')
%         figure
%         contourf(X,Y,VN); hold on
%         plot(positionsVN(:,1),positionsVN(:,2),'k.')
        
        
        % having u and v gridded we can calculate the 
        % vorticity and the divergence
        U = U';
        UC = UC';
        UN = UN';
        V = V';
        VC = VC';
        VN = VN';        
        if isempty(U) || isempty(V) || isempty(UC) || isempty(VC) || ...
                isempty(UN) || isempty(VN)
            GammaO_N = [GammaO_N NaN];
            GammaC_N = [GammaC_N NaN];
            GammaN_N = [GammaN_N NaN];
            GammaAO_N = [GammaAO_N NaN];
            GammaAC_N = [GammaAC_N NaN];
            GammaAN_N = [GammaAN_N NaN];
            VORTO_N = [VORTO_N NaN];
            VORTC_N = [VORTC_N NaN];
            VORTN_N = [VORTN_N NaN];
            DIVO_N = [DIVO_N NaN];
            DIVC_N = [DIVC_N NaN];
            DIVN_N = [DIVN_N NaN];
            p = [p pressures(ii)];
            continue
        end
    
        X = X'; Y = Y';
        x = squeeze(positionsU(:,1));
        y = squeeze(positionsU(:,2));
        [vortO, divO, Xd, Yd, GammaO, GammaAO, VORTO, DIVO] = vortDiv(U,V,X,Y,x,y,DEGREES,MONTH,DAY);
        [vortC, divC, Xd, Yd, GammaC, GammaAC, VORTC, DIVC] = vortDiv(UC,VC,X,Y,x,y,DEGREES,MONTH,DAY);
        x = squeeze(positionsUN(:,1));
        y = squeeze(positionsUN(:,2));
        [vortN, divN, Xd, Yd, GammaN, GammaAN, VORTN, DIVN] = vortDiv(UN,VN,X,Y,x,y,DEGREES,MONTH,DAY);
        VORTICITYO(:,:,ii,dd) = vortO;
        DIVERGENCO(:,:,ii,dd) = divO;
        VORTICITYC(:,:,ii,dd) = vortC;
        DIVERGENCC(:,:,ii,dd) = divC;
        VORTICITYN(:,:,ii,dd) = vortN;
        DIVERGENCN(:,:,ii,dd) = divN;
        X = X'; Y = Y'; %weirf
        
        p = [p pressures(ii)];
        if isempty(GammaO)
            GammaO_N = [GammaO_N NaN];
            GammaC_N = [GammaC_N NaN];
            GammaN_N = [GammaN_N NaN];
            GammaAO_N = [GammaAO_N NaN];
            GammaAC_N = [GammaAC_N NaN];
            GammaAN_N = [GammaAN_N NaN];
            VORTO_N = [VORTO_N NaN];
            VORTC_N = [VORTC_N NaN];
            VORTN_N = [VORTN_N NaN];
            DIVO_N = [DIVO_N NaN];
            DIVC_N = [DIVC_N NaN];
            DIVN_N = [DIVN_N NaN];
        else
            GammaO_N = [GammaO_N GammaO];
            GammaC_N = [GammaC_N GammaC];
            GammaN_N = [GammaN_N GammaN];
            GammaAO_N = [GammaAO_N GammaAO];
            GammaAC_N = [GammaAC_N GammaAC];
            GammaAN_N = [GammaAN_N GammaAN];
            VORTO_N = [VORTO_N VORTO];
            VORTC_N = [VORTC_N VORTC];
            VORTN_N = [VORTN_N VORTN];
            DIVO_N = [DIVO_N DIVO];
            DIVC_N = [DIVC_N DIVC];
            DIVN_N = [DIVN_N DIVN];
        end        

    end %pressures
    %
    
    GammaO_F(:,dd) = GammaO_N/10^6;
    GammaC_F(:,dd) = GammaC_N/10^6;
    GammaN_F(:,dd) = GammaN_N/10^6;
    GammaAO_F(:,dd) = GammaAO_N/10^6;
    GammaAC_F(:,dd) = GammaAC_N/10^6;
    GammaAN_F(:,dd) = GammaAN_N/10^6;
    
    VORTO_F(:,dd) = VORTO_N*10^3;
    VORTC_F(:,dd) = VORTC_N*10^3;
    VORTN_F(:,dd) = VORTN_N*10^3;
    DIVO_F(:,dd) = DIVO_N*10^3;
    DIVC_F(:,dd) = DIVC_N*10^3;
    DIVN_F(:,dd) = DIVN_N*10^3;
    
    subplot(1,2,1)
    plot(GammaO_N/10^6,p,'b-o','markersize',10); hold on;
    %plot(GammaC_N/10^6,p,'r-o','markersize',10)
    %plot(GammaN_N/10^6,p,'k-o','markersize',10)
    plot(GammaAO_N/10^6,p,'b--o','markersize',10)
    %plot(GammaAC_N/10^6,p,'r--o','markersize',10)
    %plot(GammaAN_N/10^6,p,'k--o','markersize',10)
    plot(p*0,p,'k','markersize',20)
    legend('line int. OBS', 'line int. CNTL', 'line int. NODPS',...
                'surf. int.')
    set(gca, 'YDir', 'reverse')
    xlabel('(10^6 m^2/s)')
    ylabel('pressure (hPa)')
    title(['Date: 2019-' num2str(MONTH,'%.2i') '-' num2str(DAY,'%.2i')])
    print('-dpng',['circulation_' num2str(MONTH,'%.2i') num2str(DAY,'%.2i') '.png'])
    
    clf
end %dates



%%
figure
set(gcf,'Position',[70 50 1100 800])
plot(nanmean(GammaO_F,2),p,'b-o','markersize',10); hold on;
plot(nanmean(GammaC_F,2),p,'r-o','markersize',10)
plot(nanmean(GammaN_F,2),p,'k-o','markersize',10)
plot(nanmean(GammaAO_F,2),p,'b--o','markersize',10)
plot(nanmean(GammaAC_F,2),p,'r--o','markersize',10)
plot(nanmean(GammaAN_F,2),p,'k--o','markersize',10)
plot(p*0,p,'k','markersize',20)
legend('line int. OBS', 'line int. CNTL', 'line int. NODPS',...
    'surf. int.')
set(gca, 'YDir', 'reverse')
xlabel('(10^6 m^2/s)')
ylabel('pressure (hPa)')
title(['mean from 8/7 to 9/30'])
%print('-dpng',['circulationMean_' num2str(MONTH,'%.2i') num2str(DAY,'%.2i') '.png'])

figure
set(gcf,'Position',[70 50 1100 800])
plot(nanmean(GammaO_F-GammaC_F,2),p,'b-o','markersize',6); hold on;
plot(nanmean(GammaO_F-GammaN_F,2),p,'r-o','markersize',6)
plot(nanmean(GammaAO_F-GammaAC_F,2),p,'b--o','markersize',6)
plot(nanmean(GammaAO_F-GammaAN_F,2),p,'r--o','markersize',6)
plot(p*0,p,'k','markersize',20)
legend('line int. OBS-CNTL', 'line int. OBS-NODP', 'surf int. OBS-CNTL',...
    'surf. int. OBS-NODP')
set(gca, 'YDir', 'reverse')
xlabel('(10^6 m^2/s)')
ylabel('pressure (hPa)')
title(['mean from 8/7 to 9/30'])
%print('-dpng',['circulationMean_' num2str(MONTH,'%.2i') num2str(DAY,'%.2i') '.png'])
%%
figure
set(gcf,'Position',[70 50 900 350])

iP = p>=500;
% boxes B2 and B1a
indBoxAll  = logical([1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1]);
% box B2
%             1 2 3 4 5 6 7 8 9 101 2 3 4 5 6 7 8 9 201 2
indBoxB2   = logical([1 0 1 0 1 1 0 1 0 0 1 0 0 1 0 1 0 1 1 1 1 1]);
% box B1a
indBoxB1a  = ~indBoxB2;

iB = indBoxAll;    STR = 'B2 and B1a'; fileN = 'ALL'; STR= ''
%iB = indBoxB2;     STR = 'B2'; fileN = 'B2';
%iB = indBoxB1a;    STR = 'B1a'; fileN = 'B1a';

[ha, pos] = tight_subplot(1, 2, [.08 .06],[.13 .1],[.1 .1])

axes(ha(1))
plot(nanmean(VORTO_F(iP,iB),2),p(iP),'g','linewidth',2); hold on;
plot(nanmean(VORTC_F(iP,iB),2),p(iP),'k','linewidth',2); hold on;
plot(nanmean(VORTN_F(iP,iB),2),p(iP),'r','linewidth',2)
plot(nanmean(VORTO_F(iP,iB),2) + nanstd(VORTO_F(iP,iB),1,2),p(iP),'g--','linewidth',2);
plot(nanmean(VORTO_F(iP,iB),2) - nanstd(VORTO_F(iP,iB),1,2),p(iP),'g--','linewidth',2);
plot(nanmean(VORTC_F(iP,iB),2) + nanstd(VORTC_F(iP,iB),1,2),p(iP),'k--','linewidth',2)
plot(nanmean(VORTC_F(iP,iB),2) - nanstd(VORTC_F(iP,iB),1,2),p(iP),'k--','linewidth',2)
plot(nanmean(VORTN_F(iP,iB),2) + nanstd(VORTN_F(iP,iB),1,2),p(iP),'r--','linewidth',2)
plot(nanmean(VORTN_F(iP,iB),2) - nanstd(VORTN_F(iP,iB),1,2),p(iP),'r--','linewidth',2)

%plot(nanmean(VORTO_F(iP,iB)-VORTC_F(iP,iB),2)+nanstd(VORTO_F(iP,iB)-VORTC_F(iP,iB),0,2),p(iP),'k--','linewidth',2)
%plot(nanmean(VORTO_F(iP,iB)-VORTC_F(iP,iB),2)-nanstd(VORTO_F(iP,iB)-VORTC_F(iP,iB),0,2),p(iP),'k--','linewidth',2)
%plot(nanmean(VORTO_F(iP,iB)-VORTN_F(iP,iB),2)+nanstd(VORTO_F(iP,iB)-VORTN_F(iP,iB),0,2),p(iP),'r--','linewidth',2)
%plot(nanmean(VORTO_F(iP,iB)-VORTN_F(iP,iB),2)-nanstd(VORTO_F(iP,iB)-VORTN_F(iP,iB),0,2),p(iP),'r--','linewidth',2)

%plot(nanmean(VORTO_F(iP,iB)-VORTC_F(iP,iB),2),p(iP),'k','linewidth',2); hold on;
%plot(nanmean(VORTO_F(iP,iB)-VORTN_F(iP,iB),2),p(iP),'r','linewidth',2)
%plot(nanmean(VORTO_F(iP,iB)-VORTC_F(iP,iB),2)+nanstd(VORTO_F(iP,iB)-VORTC_F(iP,iB),0,2),p(iP),'k--','linewidth',2)
%plot(nanmean(VORTO_F(iP,iB)-VORTC_F(iP,iB),2)-nanstd(VORTO_F(iP,iB)-VORTC_F(iP,iB),0,2),p(iP),'k--','linewidth',2)
%plot(nanmean(VORTO_F(iP,iB)-VORTN_F(iP,iB),2)+nanstd(VORTO_F(iP,iB)-VORTN_F(iP,iB),0,2),p(iP),'r--','linewidth',2)
%plot(nanmean(VORTO_F(iP,iB)-VORTN_F(iP,iB),2)-nanstd(VORTO_F(iP,iB)-VORTN_F(iP,iB),0,2),p(iP),'r--','linewidth',2)

plot([0 0],[1000 250],'color',[.8 .8 .8],'linewidth',2)
%plot(nanmean(VORTO_F(iP,iB)-VORTC_F(iP,iB),2),p(iP),'k','linewidth',2)
%plot(nanmean(VORTO_F(iP,iB)-VORTN_F(iP,iB),2),p(iP),'r','linewidth',2)
legend('OBS','YDPS', 'NDPS')
set(gca, 'YDir', 'reverse')
xlabel('vorticity (1/ks)')
ylim([250 1000])
xlim([-0.03 0.04])
ylabel('pressure (hPa)')



axes(ha(2))
% plot(nanmean(DIVO_F(iP,iB)-DIVC_F(iP,iB),2),p(iP),'k','linewidth',2); hold on;
% plot(nanmean(DIVO_F(iP,iB)-DIVN_F(iP,iB),2),p(iP),'r','linewidth',2)
% plot(nanmean(DIVO_F(iP,iB)-DIVC_F(iP,iB),2)+nanstd(DIVO_F(iP,iB)-DIVC_F(iP,iB),0,2),p(iP),'k--','linewidth',2)
% plot(nanmean(DIVO_F(iP,iB)-DIVC_F(iP,iB),2)-nanstd(DIVO_F(iP,iB)-DIVC_F(iP,iB),0,2),p(iP),'k--','linewidth',2)
% plot(nanmean(DIVO_F(iP,iB)-DIVN_F(iP,iB),2)+nanstd(DIVO_F(iP,iB)-DIVN_F(iP,iB),0,2),p(iP),'r--','linewidth',2)
% plot(nanmean(DIVO_F(iP,iB)-DIVN_F(iP,iB),2)-nanstd(DIVO_F(iP,iB)-DIVN_F(iP,iB),0,2),p(iP),'r--','linewidth',2)
% plot([0 0],[1000 250],'color',[.8 .8 .8],'linewidth',2)
% plot(nanmean(DIVO_F(iP,iB)-DIVC_F(iP,iB),2),p(iP),'k','linewidth',2)
% plot(nanmean(DIVO_F(iP,iB)-DIVN_F(iP,iB),2),p(iP),'r','linewidth',2)
plot(nanmean(DIVO_F(iP,iB),2),p(iP),'g','linewidth',2); hold on;
plot(nanmean(DIVC_F(iP,iB),2),p(iP),'k','linewidth',2)
plot(nanmean(DIVN_F(iP,iB),2),p(iP),'r','linewidth',2)
plot(nanmean(DIVO_F(iP,iB),2) + nanstd(DIVO_F(iP,iB),1,2),p(iP),'g--','linewidth',2);
plot(nanmean(DIVO_F(iP,iB),2) - nanstd(DIVO_F(iP,iB),1,2),p(iP),'g--','linewidth',2);
plot(nanmean(DIVC_F(iP,iB),2) + nanstd(DIVC_F(iP,iB),1,2),p(iP),'k--','linewidth',2)
plot(nanmean(DIVC_F(iP,iB),2) - nanstd(DIVC_F(iP,iB),1,2),p(iP),'k--','linewidth',2)
plot(nanmean(DIVN_F(iP,iB),2) + nanstd(DIVN_F(iP,iB),1,2),p(iP),'r--','linewidth',2)
plot(nanmean(DIVN_F(iP,iB),2) - nanstd(DIVN_F(iP,iB),1,2),p(iP),'r--','linewidth',2)
plot([0 0],[1000 250],'color',[.8 .8 .8],'linewidth',2)
set(gca, 'YDir', 'reverse')
xlabel('divergence (1/ks)')
ylim([250 1000])
xlim([-0.03 0.03])
text(-0.04,220,STR)
print('-dpng',['circulationVert_' fileN '.png'])










figure
set(gcf,'Position',[70 50 900 350])

iP = p>=500;
% boxes B2 and B1a
indBoxAll  = logical([1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1]);
% box B2
%             1 2 3 4 5 6 7 8 9 101 2 3 4 5 6 7 8 9 201 2
indBoxB2   = logical([1 0 1 0 1 1 0 1 0 0 1 0 0 1 0 1 0 1 1 1 1 1]);
% box B1a
indBoxB1a  = ~indBoxB2;

iB = indBoxAll;    STR = 'B2 and B1a'; fileN = 'ALL'; STR= ''
%iB = indBoxB2;     STR = 'B2'; fileN = 'B2';
%iB = indBoxB1a;    STR = 'B1a'; fileN = 'B1a';

[ha, pos] = tight_subplot(1, 2, [.08 .06],[.13 .1],[.1 .1])

axes(ha(1))
% plot(nanmean(VORTO_F(iP,iB),2),p(iP),'g','linewidth',2); hold on;
% plot(nanmean(VORTC_F(iP,iB),2),p(iP),'k','linewidth',2); hold on;
% plot(nanmean(VORTN_F(iP,iB),2),p(iP),'r','linewidth',2)
% plot(nanmean(VORTO_F(iP,iB),2) + nanstd(VORTO_F(iP,iB),1,2),p(iP),'g--','linewidth',2);
% plot(nanmean(VORTO_F(iP,iB),2) - nanstd(VORTO_F(iP,iB),1,2),p(iP),'g--','linewidth',2);
% plot(nanmean(VORTC_F(iP,iB),2) + nanstd(VORTC_F(iP,iB),1,2),p(iP),'k--','linewidth',2)
% plot(nanmean(VORTC_F(iP,iB),2) - nanstd(VORTC_F(iP,iB),1,2),p(iP),'k--','linewidth',2)
% plot(nanmean(VORTN_F(iP,iB),2) + nanstd(VORTN_F(iP,iB),1,2),p(iP),'r--','linewidth',2)
% plot(nanmean(VORTN_F(iP,iB),2) - nanstd(VORTN_F(iP,iB),1,2),p(iP),'r--','linewidth',2)

plot(nanmean(VORTO_F(iP,iB)-VORTC_F(iP,iB),2)+nanstd(VORTO_F(iP,iB)-VORTC_F(iP,iB),0,2),p(iP),'k--','linewidth',2)
plot(nanmean(VORTO_F(iP,iB)-VORTC_F(iP,iB),2)-nanstd(VORTO_F(iP,iB)-VORTC_F(iP,iB),0,2),p(iP),'k--','linewidth',2)
plot(nanmean(VORTO_F(iP,iB)-VORTN_F(iP,iB),2)+nanstd(VORTO_F(iP,iB)-VORTN_F(iP,iB),0,2),p(iP),'r--','linewidth',2)
plot(nanmean(VORTO_F(iP,iB)-VORTN_F(iP,iB),2)-nanstd(VORTO_F(iP,iB)-VORTN_F(iP,iB),0,2),p(iP),'r--','linewidth',2)
plot(nanmean(VORTO_F(iP,iB)-VORTC_F(iP,iB),2),p(iP),'k','linewidth',2); hold on;
plot(nanmean(VORTO_F(iP,iB)-VORTN_F(iP,iB),2),p(iP),'r','linewidth',2)
plot(nanmean(VORTO_F(iP,iB)-VORTC_F(iP,iB),2)+nanstd(VORTO_F(iP,iB)-VORTC_F(iP,iB),0,2),p(iP),'k--','linewidth',2)
plot(nanmean(VORTO_F(iP,iB)-VORTC_F(iP,iB),2)-nanstd(VORTO_F(iP,iB)-VORTC_F(iP,iB),0,2),p(iP),'k--','linewidth',2)
plot(nanmean(VORTO_F(iP,iB)-VORTN_F(iP,iB),2)+nanstd(VORTO_F(iP,iB)-VORTN_F(iP,iB),0,2),p(iP),'r--','linewidth',2)
plot(nanmean(VORTO_F(iP,iB)-VORTN_F(iP,iB),2)-nanstd(VORTO_F(iP,iB)-VORTN_F(iP,iB),0,2),p(iP),'r--','linewidth',2)

plot([0 0],[1000 250],'color',[.8 .8 .8],'linewidth',2)
%plot(nanmean(VORTO_F(iP,iB)-VORTC_F(iP,iB),2),p(iP),'k','linewidth',2)
%plot(nanmean(VORTO_F(iP,iB)-VORTN_F(iP,iB),2),p(iP),'r','linewidth',2)
legend('YDPS', 'NDPS')
set(gca, 'YDir', 'reverse')
xlabel('vorticity (1/ks)')
ylim([250 1000])
xlim([-0.03 0.04])
ylabel('pressure (hPa)')
text(-0.026,300,'a','fontsize',14)
%text(-0.017,300,'a','fontsize',14)



axes(ha(2))
plot(nanmean(DIVO_F(iP,iB)-DIVC_F(iP,iB),2),p(iP),'k','linewidth',2); hold on;
plot(nanmean(DIVO_F(iP,iB)-DIVN_F(iP,iB),2),p(iP),'r','linewidth',2)
plot(nanmean(DIVO_F(iP,iB)-DIVC_F(iP,iB),2)+nanstd(DIVO_F(iP,iB)-DIVC_F(iP,iB),0,2),p(iP),'k--','linewidth',2)
plot(nanmean(DIVO_F(iP,iB)-DIVC_F(iP,iB),2)-nanstd(DIVO_F(iP,iB)-DIVC_F(iP,iB),0,2),p(iP),'k--','linewidth',2)
plot(nanmean(DIVO_F(iP,iB)-DIVN_F(iP,iB),2)+nanstd(DIVO_F(iP,iB)-DIVN_F(iP,iB),0,2),p(iP),'r--','linewidth',2)
plot(nanmean(DIVO_F(iP,iB)-DIVN_F(iP,iB),2)-nanstd(DIVO_F(iP,iB)-DIVN_F(iP,iB),0,2),p(iP),'r--','linewidth',2)
plot([0 0],[1000 250],'color',[.8 .8 .8],'linewidth',2)
plot(nanmean(DIVO_F(iP,iB)-DIVC_F(iP,iB),2),p(iP),'k','linewidth',2)
plot(nanmean(DIVO_F(iP,iB)-DIVN_F(iP,iB),2),p(iP),'r','linewidth',2)
plot([0 0],[1000 250],'color',[.8 .8 .8],'linewidth',2)
set(gca, 'YDir', 'reverse')
xlabel('divergence (1/ks)')
ylim([250 1000])
xlim([-0.03 0.03])
%text(-0.04,220,STR)
text(-0.026,300,'b','fontsize',14)
%text(-0.008,300,'b','fontsize',14)
print('-dpng',['circulationV.png'])
print('-depsc',['circulationV.eps'])


stop
%%

% what are the maxima?
[min(min(min(min(VORTICITYO)))) max(max(max(max(VORTICITYO))))]
[min(min(min(min(VORTICITYC)))) max(max(max(max(VORTICITYC))))]
[min(min(min(min(VORTICITYN)))) max(max(max(max(VORTICITYN))))]

[min(min(min(min(DIVERGENCO)))) max(max(max(max(DIVERGENCO))))]
[min(min(min(min(DIVERGENCC)))) max(max(max(max(DIVERGENCC))))]
[min(min(min(min(DIVERGENCN)))) max(max(max(max(DIVERGENCN))))]


%%

MARKERS = 5;

figure
set(gcf,'Position',[70 50 700 500])

xl = -0.35;
yl = 0.4;

for i = 1:12
    p = pressures(i);
    
    [ha, pos] = tight_subplot(2, 2, [.086 .077],[.1 .1],[.1 .1]);
    axes(ha(1))
    x = VORTICITYO(:,:,i,:);
    y = VORTICITYC(:,:,i,:);
    plot(x(:),y(:),'r.','markersize',MARKERS); hold on;
    plot([xl yl],[xl yl],'k','markersize',12)
    plot([xl yl],[0 0],'k','markersize',12)
    plot([0 0],[xl yl],'k','markersize',12)
    xlabel('vorticity OBS (1/ks)')
    ylabel('vorticity CNTL (1/ks)')
    xlim([xl yl]); ylim([xl yl])
    text(0.2,0.5,['Pressure: ' num2str(p) ' hPa'],'fontsize',12)

    axes(ha(2))
    x = VORTICITYO(:,:,i,:);
    y = VORTICITYN(:,:,i,:);
    plot(x(:),y(:),'r.','markersize',MARKERS); hold on;
    plot([xl yl],[xl yl],'k','markersize',12)
    plot([xl yl],[0 0],'k','markersize',12)
    plot([0 0],[xl yl],'k','markersize',12)
    xlabel('vorticity OBS (1/ks)')
    ylabel('vorticity NODP (1/ks)')
    xlim([xl yl]); ylim([xl yl])
    
    axes(ha(3))
    x = DIVERGENCO(:,:,i,:);
    y = DIVERGENCC(:,:,i,:);
    plot(x(:),y(:),'r.','markersize',MARKERS); hold on;
    plot([xl yl],[xl yl],'k','markersize',12)
    plot([xl yl],[0 0],'k','markersize',12)
    plot([0 0],[xl yl],'k','markersize',12)
    xlabel('divergence OBS (1/ks)')
    ylabel('divergence CNTL (1/ks)')
    xlim([xl yl]); ylim([xl yl])

    axes(ha(4))
    x = DIVERGENCO(:,:,i,:);
    y = DIVERGENCN(:,:,i,:);
    plot(x(:),y(:),'r.','markersize',MARKERS); hold on;
    plot([xl yl],[xl yl],'k','markersize',12)
    plot([xl yl],[0 0],'k','markersize',12)
    plot([0 0],[xl yl],'k','markersize',12)
    xlabel('divergence OBS (1/ks)')
    ylabel('divergence NODP (1/ks)')
    xlim([xl yl]); ylim([xl yl])
    
    print('-dpng',['vortDiv_' num2str(DEGREES,'%4.2f') '_' num2str(p,'%.4i') '.png'])

    clf % clear figure content
    
end





        