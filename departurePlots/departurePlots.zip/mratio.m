function mr = mratio(p,td)
%/* compute mixing ratio, given pressure and dewpoint */
%float mratio(p,td)
%float p;                          /* pressure (Pa) */
%float td;                         /* dewpoint temperature (K) */
EPS = 0.622;                % /* vapor to dry air mol weight ratio */
temp = escalc(td);
mr = EPS*temp./(p - temp);
