function [i,j] = lonlat(lon,lat)
global lonB latB
  for ii = 1:length(lonB)-1
    if (lonB(ii)<=lon && lonB(ii+1)>=lon)
      i = ii;
      break
    end
  end
  
  for ii = 1:length(latB)-1
    if (latB(ii)<=lat && latB(ii+1)>=lat)
      j = ii;
      break
    end
  end
return;
