function smr = satmr(p,t)

EPS = 0.622;                % /* vapor to dry air mol weight ratio */
pvs = escalc(t);     %/* saturation vapor pressure */
pd = p - pvs;        %/* partial pressure of dry air at saturation */
smr = EPS*pvs./pd;     %/* saturation mixing ratio */

