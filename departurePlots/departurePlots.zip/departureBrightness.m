function dataSounding = departureBrightness(SAT_AVE,data,batch)

uniqueDateandPos = unique(data(:,1:7),'rows');
dataSounding = [];
for i = 1:length(uniqueDateandPos)
    fprintf('Batch %s, sonde %i out of %i; %4.1f%%...\n',batch,i,length(uniqueDateandPos),100.*i/length(uniqueDateandPos))
    mm = num2str(uniqueDateandPos(i,2),'%.2i');
    dd = num2str(uniqueDateandPos(i,3),'%.2i');
    if uniqueDateandPos(i,2)==8 && (uniqueDateandPos(i,3)==19 || uniqueDateandPos(i,3)==20)
        continue
    end
    minute = uniqueDateandPos(i,5);
    if minute >30
        hh = uniqueDateandPos(i,4) + 1;
    else
        hh = uniqueDateandPos(i,4);
    end
    lonS = uniqueDateandPos(i,6);
    latS = uniqueDateandPos(i,7);
    
    file = ['E:\RESEARCH\GOES16\goes_16_channel_14_2019' mm dd '.nc'];
    temp = ncread(file,'temp');
    lon  = ncread(file,'lon');
    lat  = ncread(file,'lat');
    time = ncread(file,'time');
    ind = time == hh;
    indLon = lon >= lonS-SAT_AVE & lon <= lonS+SAT_AVE;
    indLat = lat >= latS-SAT_AVE & lat <= latS+SAT_AVE;
    BRIGHT = temp(ind,indLat,indLon); % in Kelvin
    BRIGHTNESS = mean(BRIGHT(:)); % in Kelvin
    
    %   1-3   4-5    7          6          8               9       10           11            12 
    %	Date Time Latitude	 Longitude	Pressure (Pa)	Variable  Status	Observation  	Analysis departure
    ind = find(sum(abs(data(:,1:7)-uniqueDateandPos(i,:)),2)==0);
    data00 = data(ind,:);
    
    pres = data00(:,8);
    OBS  = data00(:,11);
    EXPE = data00(:,11) + data00(:,12);
    DEP = data00(:,12);
    
    verticalDeparture = trapz(pres,abs(DEP))/(pres(end)-pres(1));
    verticalDepartureMax = max(abs(DEP));
    verticalDepartureMaxPressure = pres(find(abs(DEP)==max(abs(DEP))));
    
    if verticalDeparture < 0
        pres
        data00
        stop
    end

    if  1 && uniqueDateandPos(i,2)==8 && uniqueDateandPos(i,3)==7 ...
            && uniqueDateandPos(i,4)==16 && uniqueDateandPos(i,5)==56
        
        hh = num2str(uniqueDateandPos(i,4),'%.2i');
        min = num2str(uniqueDateandPos(i,5),'%.2i');
        figure
        set(gcf,'Position',[70 50 400 500])
        plot(OBS,pres,'k','linewidth',2); hold on;
        plot(EXPE,pres,'r','linewidth',2); hold on;
        plot(EXPE*0,pres,'k--'); hold on;
        set(gca, 'YDir','reverse')
        xlabel('u (m/s)')
        ylabel('p (hPa)')
        legend('OBS','NDPS','location','west')
        text(-13,150,'a','fontsize',16)
        %text(-17,150,'b','fontsize',16)
        title(['2019/' mm '/' dd ', ' hh ':' min ', u* =  ' num2str(verticalDeparture,'%4.1f') ' (m/s)'])
        print('-dpng',['departure_' mm dd hh min '.png'])
        print('-depsc',['departure_' mm dd hh min '.eps'])
        set(gca,'fontsize',12)
        save('singleYDP_0918_1435.mat','pres','OBS','EXPE')
        stop
        close
    end
    
    dataSounding = [dataSounding; uniqueDateandPos(i,:) ...
        verticalDeparture BRIGHTNESS verticalDepartureMaxPressure verticalDepartureMax ...
        ];
end

