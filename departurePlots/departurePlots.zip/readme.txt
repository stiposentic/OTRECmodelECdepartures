Variables

2	T
3	u
4	v
7	q

I suggest you use data values for which status = 1 in cntl and (at the same time) status = 12 in nodps
