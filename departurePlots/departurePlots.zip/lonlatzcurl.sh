#!/bin/sh
#
# lonlatzcurl.sh -- Compute the vertical component of curl

if test $# != 3
then
    echo "Usage: fx fy curl"
else
    fx=$1
    fy=$2
    curl=$3

    a=111.2

	cdfmath "$fx lat cos * cfx =" | \
	cdfderiv dcfxdlat cfx lat | cdfderiv dfydlon $fy lon | \
	cdfmath "dfydlon dcfxdlat - $a / lat cos / $curl =" | \
	cdfextr -r cfx dcfxdlat dfydlon
fi
