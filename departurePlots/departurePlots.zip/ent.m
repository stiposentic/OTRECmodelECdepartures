function s = ent(p,t,qt)
%/* compute entropy */
%float ent(p,t,qt)
%float p;                         /* total pressure (Pa) */
%float t;                         /* temperature (K) */
%float qt;                        /* total water mixing ratio (g/g) */

CTOK = 273.15;              % /* Celsius to Kelvin conversion */
RD = 287.05;                %/* dry air gas constant */
EPS = 0.622;                % /* vapor to dry air mol weight ratio */
RV = (RD/EPS);              % /* water vapor gas constant */
CPD = 1005.;                % /* specific heat const pres dry air */
CPV = 1850.;                % /* specific heat const pres water vapor */
CL = 4218.;                 % /* specific heat liquid water */
CIMEAN = 1959.;             % /* specific heat of ice at -20 C */
LR = 2.5008e6;              % /* heat of vaporization at 0 C */
LFR = 3.337e5;              % /* heat of fusion at 0 C */
DLFDT = 2.45e3;             % /* slope of heat of fusion curve */
TR = 273.15;                % /* reference temperature (K) */
PR = 100000.;               % /* reference pressure (Pa) */
TMIN = 190.;                % /* minimum reasonable atmospheric temp */
GEE = 9.807;                % /* acceleration of gravity */
DELTA = 0.606;              % /* virtual temperature factor */

pvs = escalc(t);     %/* saturation vapor pressure */
pd = p - pvs;        %/* partial pressure of dry air at saturation */
qs = EPS*pvs/pd;
qv = EPS*pvs/pd;     %/* saturation mixing ratio */
if (qt < qv) 
    qv = qt;     %/* check for saturation */
end

pd = p.*(1. - qv./(EPS + qv));   %/* partial pressure of dry air */
%/* this formula is consistent both with Iribarne and Godson and with
% * Kerry Emanuel's reversible theta-e -- I also derived it myself.
% */
s = (CPD + CL*qt).*log(t./TR) - RD*log(pd./PR) + ...
       (LR + (CPV - CL)*(t - TR)).*qv./t;
if (qv > 0.) 
    s = s - qv*RV*log(qv/qs);
end
