%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% main8.m:                                                        %
% This script plots the location of the boxes                     % 
%                                                                 %
% Code written by:                                                %
%    Stipo Sentic (copyright 2021)                                %
%    Climate and Water consortium                                 %
%    New Mexico Tech                                              %
%    stipo (dot) sentic (at) nmt (dot) edu                        %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

clear all;
close all;

figure
set(gcf,'Position',[70 50 500 300])
load coastlines
plot(coastlon,coastlat,'k', 'linewidth',2); hold on;
axis equal
xlim([-95 -72])
ylim([2 14])
xlabel('longitude (deg)')
ylabel('latitude (deg)')

plot([-86 -89 -89 -86 -86],[3 3 11 11 3],'k', 'linewidth',3)
plot([-78 -81 -81 -78 -78],[4 4 7 7 4],'k', 'linewidth',3)
plot([-82 -83.25 -80.65 -79.4 -82],[9.5 11.67 13.17 11 9.5],'k', 'linewidth',3)
plot([-94.5 -93.8 -89.3 -90 -94.5],[9 13 12.2 8.2 9],'k', 'linewidth',3)

text(-80.5,5,'B1a','fontsize',14)
text(-82,11.5,'B1b','fontsize',14)
text(-88,6,'B2','fontsize',14)
text(-93,10,'B3','fontsize',14)
    
set(gca,'fontsize',12)

print('-depsc2','figure0.eps')