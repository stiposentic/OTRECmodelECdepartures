%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% main5.m:                                                        %
% This script compares vertical departures with sattelite         %
% brightness for cloudy and clear regions, plots vertical         %
% profiles.                                                       %
%                                                                 %
% Code written by:                                                %
%    Stipo Sentic (copyright 2021)                                %
%    Climate and Water consortium                                 %
%    New Mexico Tech                                              %
%    stipo (dot) sentic (at) nmt (dot) edu                        %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

clear all;
close all;
format shortG
global lonB latB

%[data; year mon day lon lat count Nsondes i Nlev pressure u v q T ];

dataCntl = load('cntl.txt');
dataNodp = load('nodps.txt');
dataCntl1 = dataCntl(dataCntl(:,4)>-100 & dataCntl(:,4)<-75 & dataCntl(:,3)>0 & dataCntl(:,3)<20 & dataCntl(:,7)==1,:);
dataNodp1 = dataNodp(dataNodp(:,4)>-100 & dataNodp(:,4)<-75 & dataNodp(:,3)>0 & dataNodp(:,3)<20 & dataNodp(:,7)==12,:);
% I suggest you use data values for which status = 1 in cntl and (at the same time) status = 12 in nodps

[dataU, dataV, dataT, dataQ] = getData(dataCntl1);
[dataUN, dataVN, dataTN, dataQN] = getData(dataNodp1);

pressures = [ 1000  950 925 900 850 800 700 600 500 400 300 250 ];
%pressures = 700;
lonB = -96.11111:1.11111:-75;
latB = 0:1.11111:16;

%%
SAT_AVE = 0.5; % 1 degree box

data = dataU; [moU, meU, mdU, brU] = departureBrightnessVert(SAT_AVE,data,'1');
data = dataV; [moV, meV, mdV, brV] = departureBrightnessVert(SAT_AVE,data,'2');
data = dataT; [moT, meT, mdT, brT] = departureBrightnessVert(SAT_AVE,data,'3');
data = dataQ; [moQ, meQ, mdQ, brQ] = departureBrightnessVert(SAT_AVE,data,'4');

data = dataUN; [moUN, meUN, mdUN, brUN] = departureBrightnessVert(SAT_AVE,data,'5');
data = dataVN; [moVN, meVN, mdVN, brVN] = departureBrightnessVert(SAT_AVE,data,'6');
data = dataTN; [moTN, meTN, mdTN, brTN] = departureBrightnessVert(SAT_AVE,data,'7');
data = dataQN; [moQN, meQN, mdQN, brQN] = departureBrightnessVert(SAT_AVE,data,'8');

save(['VertDepBright_' num2str(SAT_AVE,'%4.2f') '.mat'], ...
    'moU', 'moV', 'moQ', 'moT', ...
    'moUN', 'moVN', 'moQN', 'moTN',...
    'meU', 'meV', 'meQ', 'meT', ...
    'meUN', 'meVN', 'meQN', 'meTN',...
    'mdU', 'mdV', 'mdQ', 'mdT', ...
    'mdUN', 'mdVN', 'mdQN', 'mdTN',...
    'brU', 'brV', 'brQ', 'brT', ...
    'brUN', 'brVN', 'brQN', 'brTN');


%%
% 1-7               8                   9           10                11
%dateandPos(i,:)  verticalDeparture BRIGHTNESS maxDeparturePressure maxDep
figure
set(gcf,'Position',[70 50 800 600])
[ha, pos] = tight_subplot(2, 2, [.05 .06],[.1 .1],[.1 .1])

pointMarkerSize = 8;
lineWidth = 2;

data = mdU; bright = brU;
clear = bright>=280 & bright<1000
cloud = bright<280;
mClear = nanmean(data(clear,:),1);
sClear  = nanstd(data(clear,:),1);
mCloud = nanmean(data(cloud,:),1);
sCloud  = nanstd(data(cloud,:),1);
axes(ha(1))
plot(mClear,pressures,'k','linewidth',2); hold on;
plot([0 0],[1000 250],'color',[.8 .8 .8],'linewidth',2)
plot(mClear,pressures,'k','linewidth',2); hold on;
plot(mClear-sClear,pressures,'k--','linewidth',2);
plot(mClear+sClear,pressures,'k--','linewidth',2);
plot(mCloud,pressures,'r','linewidth',2); hold on;
plot(mCloud-sCloud,pressures,'r--','linewidth',2);
plot(mCloud+sCloud,pressures,'r--','linewidth',2);
ylim([250 1000])
set(gca, 'YDir', 'reverse' )
ylabel('pressure (hPa)')
xlabel('u (m/s)')
xlim([-4 6])

data = mdV; bright = brV;
clear = bright>=280 & bright<1000
cloud = bright<280;
mClear = nanmean(data(clear,:),1);
sClear  = nanstd(data(clear,:),1);
mCloud = nanmean(data(cloud,:),1);
sCloud  = nanstd(data(cloud,:),1);
axes(ha(2))
plot(mClear,pressures,'k','linewidth',2); hold on;
plot(mCloud,pressures,'r','linewidth',2); hold on;
plot([0 0],[1000 250],'color',[.8 .8 .8],'linewidth',2)
plot(mClear,pressures,'k','linewidth',2); hold on;
plot(mClear-sClear,pressures,'k--','linewidth',2);
plot(mClear+sClear,pressures,'k--','linewidth',2);
plot(mCloud,pressures,'r','linewidth',2); hold on;
plot(mCloud-sCloud,pressures,'r--','linewidth',2);
plot(mCloud+sCloud,pressures,'r--','linewidth',2);
ylim([250 1000])
legend('NOCLD','CLD','location','northwest')
set(gca, 'YDir', 'reverse' )
%ylabel('pressure (hPa)')
xlabel('v (m/s)')
xlim([-8 4])

data = mdQ*1000; bright = brQ;
clear = bright>=280 & bright<1000
cloud = bright<280;
mClear = nanmean(data(clear,:),1);
sClear  = nanstd(data(clear,:),1);
mCloud = nanmean(data(cloud,:),1);
sCloud  = nanstd(data(cloud,:),1);
axes(ha(3))
plot(mClear,pressures,'k','linewidth',2); hold on;
plot([0 0],[1000 250],'color',[.8 .8 .8],'linewidth',2)
plot(mClear,pressures,'k','linewidth',2); hold on;
plot(mClear-sClear,pressures,'k--','linewidth',2);
plot(mClear+sClear,pressures,'k--','linewidth',2);
plot(mCloud,pressures,'r','linewidth',2); hold on;
plot(mCloud-sCloud,pressures,'r--','linewidth',2);
plot(mCloud+sCloud,pressures,'r--','linewidth',2);
ylim([250 1000])
set(gca, 'YDir', 'reverse' )
ylabel('pressure (hPa)')
xlabel('q (g/kg)')
xlim([-2.1 2])

data = mdT; bright = brT;
clear = bright>=280 & bright<1000
cloud = bright<280;
mClear = nanmean(data(clear,:),1);
sClear  = nanstd(data(clear,:),1);
mCloud = nanmean(data(cloud,:),1);
sCloud  = nanstd(data(cloud,:),1);
axes(ha(4))
plot(mClear,pressures,'k','linewidth',2); hold on;
plot([0 0],[1000 250],'color',[.8 .8 .8],'linewidth',2)
plot(mClear,pressures,'k','linewidth',2); hold on;
plot(mClear-sClear,pressures,'k--','linewidth',2);
plot(mClear+sClear,pressures,'k--','linewidth',2);
plot(mCloud,pressures,'r','linewidth',2); hold on;
plot(mCloud-sCloud,pressures,'r--','linewidth',2);
plot(mCloud+sCloud,pressures,'r--','linewidth',2);
ylim([250 1000])
set(gca, 'YDir', 'reverse' )
ylabel('pressure (hPa)')
xlabel('T (K)')
xlim([-1 1.7])

print('-dpng',['VertDeparturesBrighness_' num2str(SAT_AVE,'%4.2f') '.png'])




figure
set(gcf,'Position',[70 50 800 600])
[ha, pos] = tight_subplot(2, 2, [.05 .06],[.1 .1],[.1 .1])

pointMarkerSize = 8;
lineWidth = 2;

data = mdUN; bright = brUN;
clear = bright>=280 & bright<1000
cloud = bright<280;
mClear = nanmean(data(clear,:),1);
sClear  = nanstd(data(clear,:),1);
mCloud = nanmean(data(cloud,:),1);
sCloud  = nanstd(data(cloud,:),1);
axes(ha(1))
plot(mClear,pressures,'k','linewidth',2); hold on;
plot([0 0],[1000 250],'color',[.8 .8 .8],'linewidth',2)
plot(mClear,pressures,'k','linewidth',2); hold on;
plot(mClear-sClear,pressures,'k--','linewidth',2);
plot(mClear+sClear,pressures,'k--','linewidth',2);
plot(mCloud,pressures,'r','linewidth',2); hold on;
plot(mCloud-sCloud,pressures,'r--','linewidth',2);
plot(mCloud+sCloud,pressures,'r--','linewidth',2);
ylim([250 1000])
set(gca, 'YDir', 'reverse' )
ylabel('pressure (hPa)')
xlabel('u (m/s)')
xlim([-4 6])

data = mdVN; bright = brVN;
clear = bright>=280 & bright<1000
cloud = bright<280;
mClear = nanmean(data(clear,:),1);
sClear  = nanstd(data(clear,:),1);
mCloud = nanmean(data(cloud,:),1);
sCloud  = nanstd(data(cloud,:),1);
axes(ha(2))
plot(mClear,pressures,'k','linewidth',2); hold on;
plot(mCloud,pressures,'r','linewidth',2); hold on;
plot([0 0],[1000 250],'color',[.8 .8 .8],'linewidth',2)
plot(mClear,pressures,'k','linewidth',2); hold on;
plot(mClear-sClear,pressures,'k--','linewidth',2);
plot(mClear+sClear,pressures,'k--','linewidth',2);
plot(mCloud,pressures,'r','linewidth',2); hold on;
plot(mCloud-sCloud,pressures,'r--','linewidth',2);
plot(mCloud+sCloud,pressures,'r--','linewidth',2);
ylim([250 1000])
legend('NOCLD','CLD','location','northwest')
set(gca, 'YDir', 'reverse' )
%ylabel('pressure (hPa)')
xlabel('v (m/s)')
xlim([-8 4])

data = mdQN*1000; bright = brQN;
clear = bright>=280 & bright<1000
cloud = bright<280;
mClear = nanmean(data(clear,:),1);
sClear  = nanstd(data(clear,:),1);
mCloud = nanmean(data(cloud,:),1);
sCloud  = nanstd(data(cloud,:),1);
axes(ha(3))
plot(mClear,pressures,'k','linewidth',2); hold on;
plot([0 0],[1000 250],'color',[.8 .8 .8],'linewidth',2)
plot(mClear,pressures,'k','linewidth',2); hold on;
plot(mClear-sClear,pressures,'k--','linewidth',2);
plot(mClear+sClear,pressures,'k--','linewidth',2);
plot(mCloud,pressures,'r','linewidth',2); hold on;
plot(mCloud-sCloud,pressures,'r--','linewidth',2);
plot(mCloud+sCloud,pressures,'r--','linewidth',2);
ylim([250 1000])
set(gca, 'YDir', 'reverse' )
ylabel('pressure (hPa)')
xlabel('q (g/kg)')
xlim([-2.1 2])

data = mdTN; bright = brTN;
clear = bright>=280 & bright<1000
cloud = bright<280;
mClear = nanmean(data(clear,:),1);
sClear  = nanstd(data(clear,:),1);
mCloud = nanmean(data(cloud,:),1);
sCloud  = nanstd(data(cloud,:),1);
axes(ha(4))
plot(mClear,pressures,'k','linewidth',2); hold on;
plot([0 0],[1000 250],'color',[.8 .8 .8],'linewidth',2)
plot(mClear,pressures,'k','linewidth',2); hold on;
plot(mClear-sClear,pressures,'k--','linewidth',2);
plot(mClear+sClear,pressures,'k--','linewidth',2);
plot(mCloud,pressures,'r','linewidth',2); hold on;
plot(mCloud-sCloud,pressures,'r--','linewidth',2);
plot(mCloud+sCloud,pressures,'r--','linewidth',2);
ylim([250 1000])
set(gca, 'YDir', 'reverse' )
ylabel('pressure (hPa)')
xlabel('T (K)')
xlim([-1 1.7])

print('-dpng',['VertDeparturesBrighnessN_' num2str(SAT_AVE,'%4.2f') '.png'])