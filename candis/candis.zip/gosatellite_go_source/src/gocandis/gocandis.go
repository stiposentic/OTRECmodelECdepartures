// Gocandis is a go package for reading and writing Candis files.
package gocandis

import (
	"fmt"
	"os"
	"strings"
	"strconv"
	"math"
)

// Structure for holding a candis field
type Field struct {
	Name string
	Dlist []string
	Size int
	Data []float64
}

// Structure for holding a candis file
type Candis struct {
	Comments []string
	Pmap map[string]string
	Dnames []string
	Dsizes []int
	Sfields []Field
	Vfields []Field
	fileptr *os.File
}

// ===================================================================
// External functions to read a candis file
// ===================================================================

// Getcandis -- read in and decode a candis file
func GetCandis(filename string) (c *Candis) {

	// create a new candis structure
	c = new(Candis)

	// get the file pointer -- if name == "-" get stdin
	if filename == "-" {
		myfileptr := os.Stdin
		c.fileptr = myfileptr
	} else {
		myfileptr, err := os.Open(filename)
		if err != nil {
			fmt.Fprintln(os.Stderr,"Candis: error on opening input file")
			os.Exit(1)
		}
		c.fileptr = myfileptr
	}

	// prepare to parse Candis header
	elist := make([]string,0)
	tag := "i"
	c.Pmap = make(map[string]string)

	for {
		myline1 := readline(c.fileptr)
		myline := strings.TrimRight(myline1, "\n")

		if myline == "*" {
			break
		}

		switch myline {
		case "***comments***":
			if tag != "i" {
				fmt.Fprintln(os.Stderr,"Candis: out of order comments")
				os.Exit(1)
			}
			tag = "c"
		case "***parameters***":
			if tag != "c" {
				fmt.Fprintln(os.Stderr,"Candis: out of order parameters")
				os.Exit(1)
			}
			tag = "p"
		case "***static_fields***":
			if tag != "p" {
				fmt.Fprintln(os.Stderr,"Candis: out of order static fields")
				os.Exit(1)
			}
			tag = "s"
		case "***variable_fields***":
			if tag != "s" {
				fmt.Fprintln(os.Stderr,"Candis: out of order static fields")
				os.Exit(1)
			}
			tag = "v"
		case "***format***":
			if tag != "v" {
				fmt.Fprintln(os.Stderr,"Candis: out of order format")
				os.Exit(1)
			}
			tag = "f"
		default:
			switch tag {
			case "c":
				c.Comments = append(c.Comments, myline)
			case "p":
				elist = strings.Fields(myline)
				if len(elist) != 2 {
					fmt.Fprintln(os.Stderr,"Candis: parameter format wrong")
					os.Exit(1)
				}
				c.Pmap[elist[0]] = elist[1]
			case "s":
				elist = strings.Fields(myline)
				c.Sfields = append(c.Sfields, fieldparse(elist))

				if len(elist) == 7 && elist[0] == elist[5] {
					c.Dnames = append(c.Dnames, elist[0])
					dsize := getint(elist[6])
					c.Dsizes = append(c.Dsizes, dsize)
				}
			case "v":
				elist = strings.Fields(myline)
				c.Vfields = append(c.Vfields, fieldparse(elist))
			}
		}
	}

	// get the static slice data -- may be zero fields
	getslice(c.Sfields, c.fileptr)

	// get the first variable slice
	if getslice(c.Vfields, c.fileptr) == 0 {
		fmt.Fprintln(os.Stderr,"Candis: no first variable slice")
		os.Exit(1)
	}

	// we are done
	return c
}

// Retrieve the comments
func (candis *Candis) GetComments() (comments []string) {

	// copy the list of comments
	comments = candis.Comments
	return
}

// Retrieve the names of parameters
func (candis *Candis) GetParamNames() (pnames []string) {

	// initialize the parameter name list
	pnames = make([]string,0,50)

	// loop through the parameter list to extract names
	for pname, _ := range candis.Pmap {
		pnames = append(pnames,pname)
	}
	return
}

// Get the value of a specified parameter
func (candis *Candis) GetParamValue(pname string) (pvalue string) {

	// grab the parameter value from the candis structure
	pvalue, ok := candis.Pmap[pname]
	if !ok {
		fmt.Fprintln(os.Stderr,"requesting value of non-existent parameter")
		os.Exit(1)
	}
	return
}

// Retrieve the names of dimensions
func (candis *Candis) GetDimNames() (dnames []string) {

	// copy the list of dimension names
	dnames = candis.Dnames
	return
}

// Retrieve dimension data by name of dimension
func (candis *Candis) GetDimData(dname string) (dimdata []float64) {

	// first check to see if this is a dimension
	for _, dnameactual := range candis.Dnames {
		if dname == dnameactual {

			// if it is a dimension, retrieve from static slice
			for _, dimfield := range candis.Sfields {
				if dimfield.Name == dname {
					dimdata = dimfield.Data
					return
				}
			}
		}
	}

	// can't find it
	fmt.Fprintln(os.Stderr,"Candis: can't find requested dimension")
	os.Exit(1)
	return
}

// Retrieve the names of variable fields
func (candis *Candis) GetVFieldNames() (vfnames []string) {

	// initialize the field name list
	vfnames = make([]string,0,50)

	// loop through the fields to extract names
	for _, vfield := range candis.Vfields {
		vfnames = append(vfnames,vfield.Name)
	}
	return
}

// Retrieve field dimension list by name of field
func (candis *Candis) GetFieldDims(fname string) (fielddims []string) {

	// try variable slice first
	for _, myfield := range candis.Vfields {
		if myfield.Name == fname {
			fielddims = myfield.Dlist
			return
		}
	}

	// then try static slice
	for _, myfield := range candis.Sfields {
		if myfield.Name == fname {
			fielddims = myfield.Dlist
			return
		}
	}

	// didn't find it
	fmt.Fprintln(os.Stderr,"Candis: can't find requested field")
	os.Exit(1)
	return
}

// Retrieve field data by name
func (candis *Candis) GetFieldData(fname string) (fielddata []float64) {

	// try variable slice first
	for _, myfield := range candis.Vfields {
		if myfield.Name == fname {
			fielddata = myfield.Data
			return
		}
	}

	// then try static slice
	for _, myfield := range candis.Sfields {
		if myfield.Name == fname {
			fielddata = myfield.Data
			return
		}
	}

	// didn't find it
	fmt.Fprintln(os.Stderr,"Candis: can't find requested field")
	os.Exit(1)
	return
}

// Get data for a variable slice beyond first -- return zero if no such slice
func (candis *Candis) GetNextVSlice() (ssize int) {
	if candis.fileptr == nil {
		fmt.Fprintln(os.Stderr,"Candis: file not open -- can't get next slice")
		os.Exit(1)
	}
	ssize = getslice(candis.Vfields, candis.fileptr)
	return
}

// ===================================================================
// External functions to create or update a candis structure
// ===================================================================

// Return a null candis structure
func NullCandis() (c *Candis) {
	c = new(Candis)
	c.Pmap = make(map[string]string)
	return
}

// Add a comment to a candis structure
func (candis *Candis) AddComment(cline string) {
	candis.dieifopen()
	candis.Comments = append(candis.Comments, cline)
	return
}

// Add a parameter to a candis structure
func (candis *Candis) AddParam(pname string, pval string) {
	candis.dieifopen()
	candis.Pmap[pname] = pval
	return
}

// Add a dimension to a candis structure
func (candis *Candis) AddDim(dname string, data []float64) {
	candis.dieifopen()
	size := len(data)
	candis.Dnames = append(candis.Dnames, dname)
	candis.Dsizes = append(candis.Dsizes, size)
	newfield := new(Field)
	newfield.Name = dname
	newfield.Dlist = make([]string,1)
	newfield.Dlist[0] = dname
	newfield.Size = size
	newfield.Data = data
	candis.Sfields = append(candis.Sfields, *newfield)

	// add corresponding parameters if data length > 1
	if len(data) > 1 {
		dvarname := "d" + dname
		varname0 := dname + "0"
		dvarvalue := fmt.Sprintf("%g", data[1] - data[0])
		varvalue0 := fmt.Sprintf("%g", data[0])
		candis.AddParam(varname0, varvalue0)
		candis.AddParam(dvarname, dvarvalue)
	}
	return
}

// Add a variable field to a candis structure
func (candis *Candis) AddVField(name string, dlist []string, data []float64) {
	candis.dieifopen()
	newfield := new(Field)
	newfield.Name = name
	newfield.Dlist = dlist
	lastdim := -1
	// check to see that there are no more than 4 dimensions
	if len(dlist) > 4 {
		fmt.Fprintln(os.Stderr,"Candis: more than 4 dimensions requested for a field")
		os.Exit(1)
	}
	
	// check to see if dlist matches dimension list
	size := 1
	for _, indname := range dlist {
		matchname := false
		for i, dname := range candis.Dnames {
			if indname == dname {
				if i <= lastdim {
					fmt.Fprintln(os.Stderr,"Candis: out of order dimension while adding field")
					os.Exit(1)
				}
				lastdim = i
				matchname = true
				size = size*candis.Dsizes[i]
				break
			}
		}
		if !matchname {
			fmt.Fprintln(os.Stderr,"Candis: input field dimension doesn't exist")
			os.Exit(1)
		}
	}
	newfield.Size = size
	
	// check to see if header size equals data size
	if size != len(data) {
		fmt.Fprintln(os.Stderr,"Candis: input field size doesn't match data size")
		os.Exit(1)
	}
	
	newfield.Data = data
	candis.Vfields = append(candis.Vfields, *newfield)
	return
}

// ===================================================================
// External functions to write a candis structure
// ===================================================================

func (candis *Candis) PutCandis(outfile string) {

	// create the file pointer -- if name == "-" get stdout
	if outfile == "-" {
		myfileptr := os.Stdout
		candis.fileptr = myfileptr
	} else {
		myfileptr, err := os.Create(outfile)
		if err != nil {
			fmt.Fprintln(os.Stderr,"Candis: error on file creation")
			os.Exit(1)
		}
		candis.fileptr = myfileptr
	}

	// write the comments
	writestring(candis.fileptr,"***comments***\n")
	for _, comment := range candis.Comments {
		writestring(candis.fileptr,comment + "\n")
	}

	// write the parameters
	writestring(candis.fileptr,"***parameters***\n")
	for pname, pvalue := range candis.Pmap {
		writestring(candis.fileptr,pname + " " + pvalue + "\n")
	}

	// write static fields
	writestring(candis.fileptr,"***static_fields***\n")
	for _, field := range candis.Sfields {
		writefield(field, candis)
	}

	// write variable fields
	writestring(candis.fileptr,"***variable_fields***\n")
	for _, field := range candis.Vfields {
		writefield(field, candis)
	}

	// write format stuff at end of header
	writestring(candis.fileptr,"***format***\nfloat\n*\n")

	// write a static slice
	putslice(candis.Sfields, candis.fileptr)

	// write the first variable slice
	putslice(candis.Vfields, candis.fileptr)
	return
}

// Update variable field data in an existing candis structure
func (candis *Candis) UpdateVField(fname string, data []float64) {
	for i, vfield := range candis.Vfields {
		if vfield.Name == fname {
			if len(data) != len(vfield.Data) {
				fmt.Fprintln(os.Stderr,"Candis: update vfield data wrong size")
				os.Exit(1)
			}
			candis.Vfields[i].Data = data
			return
		}
	}
	fmt.Fprintln(os.Stderr,"Candis: trying to update non-existent vfield")
	os.Exit(1)
	return
}

// Put another variable slice
func (candis *Candis) PutNextVSlice() {

	// first check if open for write
	if candis.fileptr == nil {
		fmt.Fprintln(os.Stderr,"Candis: writing next slice to a non-open file")
		os.Exit(1)
	}

	// write the slice
	putslice(candis.Vfields, candis.fileptr)
	return
}

// ===================================================================
// External function Close works for both input and output
// ===================================================================

// Close a file and zero the file pointer
func (candis *Candis) CloseCandis() {
	err := candis.fileptr.Close()
	if err != nil {
		fmt.Fprintln(os.Stderr,"Candis: error on closing file")
		os.Exit(1)
	}
	candis.fileptr = nil
	return
}

// ===================================================================
// External functions for multidimensional indexing
// ===================================================================

// Creates a 2-D unflattened copy of input float64 slice
func Unflatten2(n1, n2 int, flat []float64) (unflat [][]float64) {

	// check consistency
	n := n1*n2
	if len(flat) != n {
		fmt.Fprintln(os.Stderr,"dimension sizes do not match slice size")
		os.Exit(1)
	}

	// unflatten in place
	unflat = make([][]float64,n1)
	for i1 := 0; i1 < n1; i1++ {
		j1 := i1*n2
		j2 := j1 + n2
		unflat[i1] = flat[j1:j2]
	}

	// return the unflattened slice
	return
}

// Creates a 3-D unflattened copy of input float64 slice
func Unflatten3(n1, n2, n3 int, flat []float64) (unflat [][][]float64) {

	// check consistency
	n := n1*n2*n3
	if len(flat) != n {
		fmt.Fprintln(os.Stderr,"dimension sizes do not match slice size")
		os.Exit(1)
	}

	// unflatten in place
	unflat = make([][][]float64,n1)
	for i1 := 0; i1 < n1; i1++ {
		unflat[i1] = make([][]float64,n2)
		for i2 := 0; i2 < n2; i2++ {
			j1 := (i1*n2 + i2)*n3
			j2 := j1 + n3
			unflat[i1][i2] = flat[j1:j2]
		}
	}

	// return the unflattened slice
	return
}

// Creates a 4-D unflattened copy of input float64 slice
func Unflatten4(n1, n2, n3, n4 int, flat []float64) (unflat [][][][]float64) {

	// check consistency
	n := n1*n2*n3*n4
	if len(flat) != n {
		fmt.Fprintln(os.Stderr,"dimension sizes do not match slice size")
		os.Exit(1)
	}

	// unflatten in place
	unflat = make([][][][]float64,n1)
	for i1 := 0; i1 < n1; i1++ {
		unflat[i1] = make([][][]float64,n2)
		for i2 := 0; i2 < n2; i2++ {
			unflat[i1][i2] = make([][]float64,n3)
			for i3 := 0; i3 < n3; i3++ {
				j1 := ((i1*n2 + i2)*n3 + i3)*n4
				j2 := j1 + n4
				unflat[i1][i2][i3] = flat[j1:j2]
			}
		}
	}

	// return the unflattened slice
	return
}

// Creates a flattened copy of a 2-D unflattened float64 slice
func Flatten2(unflat [][]float64) (flat []float64) {

	// get dimension sizes
	n1 := len(unflat)
	n2 := len(unflat[0])
	n := n1*n2

	// allocate the flattened slice
	flat = make([]float64,n)

	// transfer the data
	for i1 := 0; i1 < n1; i1++ {
		for i2 := 0; i2 < n2; i2++ {
			flat[i1*n2 + i2] = unflat[i1][i2]
		}
	}

	// return the flattened array
	return
}

// Creates a flattened copy of a 3-D unflattened float64 slice
func Flatten3(unflat [][][]float64) (flat []float64) {

	// get dimension sizes
	n1 := len(unflat)
	n2 := len(unflat[0])
	n3 := len(unflat[0][0])
	n := n1*n2*n3

	// allocate the flattened slice
	flat = make([]float64,n)

	// transfer the data
	for i1 := 0; i1 < n1; i1++ {
		for i2 := 0; i2 < n2; i2++ {
			for i3 := 0; i3 < n3; i3++ {
				flat[(i1*n2 + i2)*n3 + i3] = unflat[i1][i2][i3]
			}
		}
	}

	// return the flattened array
	return
}

// Creates a flattened copy of a 4-D unflattened float64 slice
func Flatten4(unflat [][][][]float64) (flat []float64) {

	// get dimension sizes
	n1 := len(unflat)
	n2 := len(unflat[0])
	n3 := len(unflat[0][0])
	n4 := len(unflat[0][0][0])
	n := n1*n2*n3*n4

	// allocate the flattened slice
	flat = make([]float64,n)

	// transfer the data
	for i1 := 0; i1 < n1; i1++ {
		for i2 := 0; i2 < n2; i2++ {
			for i3 := 0; i3 < n3; i3++ {
				for i4 := 0; i4 < n4; i4++ {
					flat[((i1*n2 + i2)*n3 + i3)*n4 + i4] = unflat[i1][i2][i3][i4]
				}
			}
		}
	}

	// return the flattened array
	return
}

// ===================================================================
// Internal functions below this line
// ===================================================================

// Write a candis field header line
func writefield(field Field, candis *Candis) {
	fname := field.Name
	ndims := len(field.Dlist)
	fstring := fmt.Sprintf("%s 1 0 l %d", fname, ndims)
	for _, dname := range field.Dlist {
		for i, dnamelist := range candis.Dnames {
			if dname == dnamelist {
				dsizeint := candis.Dsizes[i]
				dsize := fmt.Sprintf("%d",dsizeint)
				fstring = fstring + " " + dname + " " + dsize
			}
		}
	}
	writestring(candis.fileptr,fstring + "\n")
}

// parse a field line into a Field struct
func fieldparse(elist []string) (f Field) {
	f.Name = elist[0]
	
	ndims := getint(elist[4])
	
	f.Dlist = make([]string,0)
	f.Size = 1
	if ndims >= 1 {
		f.Dlist = append(f.Dlist, elist[5])
		f.Size = f.Size*getint(elist[6])
	}
	if ndims >= 2 {
		f.Dlist = append(f.Dlist, elist[7])
		f.Size = f.Size*getint(elist[8])
	}
	if ndims >= 3 {
		f.Dlist = append(f.Dlist, elist[9])
		f.Size = f.Size*getint(elist[10])
	}
	if ndims >= 4 {
		f.Dlist = append(f.Dlist, elist[11])
		f.Size = f.Size*getint(elist[12])
	}
	return
}

// get the size of a slice from the slice header
func getslicesize(inreader *os.File) (ssize int) {

	// default ssize value
	ssize = 0

	// checks first byte for new vs old header format -- @ indicates new
	firstbyte := make([]byte, 1)
	nread := myreader(inreader, firstbyte)
	if nread == 0 {
		return
	}
		
	firstchar := string(firstbyte)
	var headerstring string

	// old header format is 8 bytes; new format is 16 bytes
	if firstchar == "@" {
		headerbytes := make([]byte, 15)
		myreader(inreader, headerbytes)
		headerstring = string(headerbytes)
	} else {
		headerbytes := make([]byte, 8)
		headerbytes[0] = firstbyte[0]
		myreader(inreader, headerbytes[1:])
		headerstring = string(headerbytes)
	}

	ssize = getint(strings.TrimLeft(headerstring, " "))
	return
}

// get the size of the named dimension and exit if it doesn't exist
func getdsize(dname string, dnames []string, dsizes []int) (dsize int) {
	for i, name := range dnames {
		if name == dname {
			dsize = dsizes[i]
			return
		}
	}

	// nothing by the specified name
	fmt.Fprintln(os.Stderr,"Candis: requested dimension name doesn't exist")
	os.Exit(1)
	return
}

// get the size of a slice from the file header
func getslicehsize(fields []Field) (hssize int) {
	hssize = 0
	for _, field := range fields {
		hssize = hssize + field.Size
	}
	return
}

func getint(intstring string) (intval int) {
	intval, err := strconv.Atoi(intstring)
	if err != nil {
		fmt.Fprintln(os.Stderr,"Candis: string does not represent int")
		os.Exit(1)
	}
	return
}

// Input data into the fields in a slice -- if the slice size is zero
// exit returning this zero value
func getslice(fields []Field, fileptr *os.File) (ssize int) {
	
	// check consistency of static slice size
	ssize = getslicesize(fileptr)
	if ssize == 0 {
		return
	}
	hssize := getslicehsize(fields)
	if ssize != hssize {
		fmt.Fprintln(os.Stderr,"hssize,ssize:", hssize,ssize)
		os.Exit(1)
	}

	// loop over fields in slice
	for i, field := range fields {

		// get size of slice
		nfloat32 := field.Size
		nbytes := nfloat32*4

		// read from raw byte stream -- may need multiple
		// reads on pipe input to get full buffer
		inbuff := make([]byte, nbytes)
		myreader(fileptr, inbuff)

		// convert to float64s assuming big endian float32 bytes
		// in input stream, allocating space if needed
		if len(fields[i].Data) == 0 {
			fields[i].Data = make([]float64, nfloat32)
		}
		for j := 0; j < nfloat32; j++ {
			bslice := inbuff[4*j:4*(j + 1)]
			fields[i].Data[j] = float64(bytesToFloat32(bslice))
		}
	}
	
	return
}

// Grab field data and write it to output after doing conversions
func putslice(fields []Field, fileptr *os.File) {

	// compute size of slice
	ssize := 0
	for _, field := range fields {
		ssize = ssize + field.Size
	}

	// create and write header
	sheader := fmt.Sprintf("@%15d", ssize)
	writestring(fileptr, sheader)

	// convert from float64 to byte stream
	ptr := 0
	outbuff := make([]byte, ssize*4)
	for _, field := range fields {
		for _, datapt := range field.Data {
			datapt32 := float32(datapt)
			float32ToBytes(datapt32, outbuff[ptr:ptr + 4])
			ptr = ptr + 4
		}
	}
	_, err := fileptr.Write(outbuff)
	if err != nil {
		fmt.Fprintln(os.Stderr,"Candis: error on slice write")
		os.Exit(1)
	}

	return
}

// get a float32 from 4 bytes in big endian order
func bytesToFloat32(b []byte) float32 {
	i := uint32(b[0])<<24 | uint32(b[1])<<16 | uint32(b[2])<<8 |
		uint32(b[3])
	return math.Float32frombits(i)
}

// get 4 bytes in big endian order from a float32
func float32ToBytes(v float32, b []byte) {
	ui := math.Float32bits(v)
	b[0] = byte(ui>>24)
	b[1] = byte(ui>>16)
	b[2] = byte(ui>>8)
	b[3] = byte(ui)
	return
}

// test to see if file is open and die if so
func (candis *Candis) dieifopen() {
	if candis.fileptr != nil {
		fmt.Fprintln(os.Stderr,"Candis: can't change header of struct with open io")
		os.Exit(1)
	}
	return
}

// read a line from the specified file pointer,
// converting to string, including trailing newline
// maximum line length including newline is set to 202 bytes
func readline(f *os.File) (line string) {
	maxbytes := 202
	inbuff := make([]byte, maxbytes + 1)
	nbytes := 0
	for {
		if nbytes >= maxbytes {
			fmt.Fprintln(os.Stderr,"Candis: input line too long")
			os.Exit(1)
		}
		nread := myreader(f, inbuff[nbytes:nbytes + 1])
		if nread != 1 {
			return ""
		}
		if inbuff[nbytes] == '\n' {
			break
		}
		nbytes = nbytes + 1
	}
	return string(inbuff[:nbytes + 1])
}

// write a string to the specified file pointer
func writestring(f *os.File, mystring string) {
	_, err := f.Write([]byte(mystring))
	if err != nil {
		fmt.Fprintln(os.Stderr,"Candis: error on string write")
		os.Exit(1)
	}
}

// reliable read -- reads from pipes might not get entire desired block
// on the first try
func myreader(fileptr *os.File, inbuff []byte) (totalread int) {
	nbytes := len(inbuff)
	totalread = 0
	for {
		nread, _ := fileptr.Read(inbuff[totalread:nbytes])
		totalread += nread

		// this indicates EOF
		if totalread == 0 {
			return
		}

		// this shouldn't happen
		if totalread > nbytes {
			fmt.Fprintln(os.Stderr,"Candis: read too many bytes!")
			os.Exit(1)
		}

		// quit trying when we have all we need
		if totalread == nbytes {
			return
		}
	}
}
