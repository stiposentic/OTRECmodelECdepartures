package main
import (
	"fmt"
	"gocandis"
	"os"
	"math"
	"strconv"
)


const radiusEquator = 6378137.0      // equitorial radius in meters
const radiusPolar = 6356752.31414    // polar radius in meters

var dataSatLon float64         // satillite longitude in radians
var dataSatLat float64         // satellite latitude in radians
var dataSatHeight float64      // satellite height in meters

const bad = 9.99999e29
const badlim = 9.99e29

//var err error
//var latmin float64
//var latmax float64
//var lonmin float64
//var lonmax float64

func help() {
        fmt.Println("Usage: gosatellite latmin latmax lonmin lonmax resolution")
	fmt.Println("Satellite height variable should be called satellite_height and is in (m).")
	fmt.Println("Satellite latitude variable should be called satellite_lat")
	fmt.Println("Satellite longitude variable should be called satellite_lon")
        os.Exit(1)
}


// A basic function for converting from a regualar cartesian grid
// to a spherical coordinate system that is centered on the earth.
// The intent is to take images from the GOES-16 satellite which is in
// a regualar cartesian coordinate system and convert it to a spherical
// coordinate grid.

// The methodology to do this is describe in the GOES-16 user documentation
// located at https://www.goes-r.gov/users/docs/PUG-L1b-vol3.pdf 
// and starts on page 21

func earth2grid(lat float64, lon float64) (float64, float64) {
	// Distance between the satellite and the center of the Earth
	H := radiusEquator + dataSatHeight
	e := 0.0818191910435

	// geocentric latitude
	geolat := math.Atan(math.Pow(radiusPolar/radiusEquator,2)*math.Tan(lat * math.Pi/180))

	// geocentric distance to the pointon the ellipsoid
	rc := radiusPolar / math.Sqrt(1-e*e * math.Pow(math.Cos(geolat),2))

	// intermediary coordinates
	sx := H - rc * math.Cos(geolat) * math.Cos((lon - dataSatLon)*math.Pi/180)
	sy := -rc * math.Cos(geolat)*math.Sin((lon - dataSatLon)*math.Pi/180)
	sz := rc * math.Sin(geolat)

	y := math.Atan(sz/sx)
	x := math.Asin(-sy/math.Sqrt(sx*sx+sy*sy+sz*sz))

	return y, x
}

func grid2earth(x float64, y float64) (float64, float64) {
	sinx := math.Sin(x)
	cosx := math.Cos(x)
	siny := math.Sin(y)
	cosy := math.Cos(y)
	H := dataSatHeight + radiusEquator

	// calculate a,b, & c from documentation
	a := sinx*sinx + cosx*cosx*(cosy*cosy + math.Pow(radiusEquator/radiusPolar,2) * siny*siny)
	b := -2 * H * cosx * cosy
	c := H*H - radiusEquator*radiusEquator

	// Distance from satellite to projection point
	r := (-b - math.Sqrt(b*b -4 * a * c))/(2*a)

	// Calculate sx, sy, and sz intermediary products
	sx := r * cosx * cosy
	sy := -r * sinx
	sz := r * cosx * siny

	// Get lat and lon from intermediary products
	lat := math.Atan(math.Pow(radiusEquator/radiusPolar,2) * sz / math.Sqrt(math.Pow(H-sx,2)+sy*sy)) *180 / math.Pi
	lon := dataSatLon - math.Atan(sy/(H-sx))*180/math.Pi

	return lat, lon
}

func main() {
	// Collect arguments from commandline
        args := os.Args[1:]
        if len(args) != 5 {
                help()
        }

	// get lat/lon mins and maxes from arguments
	latmin, err := strconv.ParseFloat(args[0], 64)
	if err != nil {
		fmt.Println("Unexpected value for latmin got " + args[0])
		os.Exit(1)
        }
	latmax, err := strconv.ParseFloat(args[1], 64)
	if err != nil {
                fmt.Println("Unexpected value for latmax got " + args[1])
                os.Exit(1)
        }
	lonmin, err := strconv.ParseFloat(args[2], 64)
	if err != nil {
                fmt.Println("Unexpected value for lonmin got " + args[2])
                os.Exit(1)
        }
	lonmax, err := strconv.ParseFloat(args[3], 64)
	if err != nil {
                fmt.Println("Unexpected value for lonmax got " + args[3])
                os.Exit(1)
        }
	resolution, err := strconv.ParseFloat(args[4],64)
	if err != nil {
		fmt.Println("Unexpected value for resolution got " + args[4])
		os.Exit(1)
	}


	// variable names containting sat data
	satHeightDim := "satellite_height"
	satLatDim := "satellite_lat"
	satLonDim := "satellite_lon"
	radField := "rad"

	// Read candis file from pipeline
	a := gocandis.GetCandis("-")

	// Collect assorted information
	mycomments := a.GetComments()
	myparams := a.GetParamNames()
	myvfields := a.GetVFieldNames()

	// Create a dummy candis file
	b := gocandis.NullCandis()

	// Get Comments, pass them through
	for _, comment := range mycomments {
		b.AddComment(comment)
	}

	// Add gosatellite comment
	b.AddComment("gosatellite: " +  args[0] + " " + args[1] + " " + args[2] + " " + args[3] + " " + args[4])

	// Pass parameters through
	for _, pname := range myparams {
		pvalue := a.GetParamValue(pname)
		b.AddParam(pname,pvalue)
	}

	// collect values for satellite position data
	dataSatLat = a.GetFieldData(satLatDim)[0]
	dataSatLon = a.GetFieldData(satLonDim)[0]
	dataSatHeight = a.GetFieldData(satHeightDim)[0]

	// delta x and delta y
	dx := 0.000056
	dy := -0.000056

	x0 := -0.151844
	y0 := 0.151844

	x := a.GetFieldData("x")
	y := a.GetFieldData("y")

	// make lat and lon dims
	lenlat := int(math.Round(math.Abs(latmax-latmin)*resolution)) + 1
	dlat := 1/resolution
	lenlon := int(math.Round(math.Abs(lonmax-lonmin)*resolution)) + 1
	dlon := 1/resolution


	lat := make([]float64,lenlat)
	lon := make([]float64,lenlon)

	// fill lat/lon dims with values
	for i := 0; i < lenlat; i++ {
		lat[i] = latmin + float64(i) * dlat
	}
	for i := 0; i < lenlon; i++ {
		lon[i] = lonmin + float64(i) * dlon
	}

	// get data from oldrad and make newrad
	oldrad := gocandis.Unflatten2(len(x),len(y),a.GetFieldData(radField))
	newrad := make([][]float64,lenlon)
	for i := range newrad {
		newrad[i] = make([]float64,lenlat)
	}

	// for each lat/lon pair, select the corresponding data from oldrad
	// and input into newrad
	for i, val1 := range lon {
		for j, val2 := range lat {
			cy, cx := earth2grid(val2,val1)
			ry := int(math.Round((cy-y0)/dy))
			rx := int(math.Round((cx-x0)/dx))

			newrad[i][j] = oldrad[rx][ry]
		}
	}

	b.AddDim("lon",lon)
	b.AddDim("lat",lat)

	b.AddVField("rad",[]string{"lon","lat"},gocandis.Flatten2(newrad))

	// pass through all vfields that aren't using x/y coordinates
	for _, dname := range myvfields {
		dnameArr := a.GetFieldDims(dname)
		if len(dnameArr) == 0 {
			b.AddVField(dname,dnameArr,a.GetFieldData(dname))
		}
	}



	a.CloseCandis()
	b.PutCandis("-")
	b.CloseCandis()
}
